'use strict';
/* ===== Caydiid v1.3: TikTok-style home + no-code live / calls / messages (PeerJS) ===== */
const digits=s=>String(s||'').replace(/\D/g,''),pj=()=>typeof Peer!=='undefined',slug=s=>String(s||'').replace(/[^a-z0-9]/gi,'').toLowerCase();
LIVES.length=0;
/* ---- Home look ---- */
const FT=[['co','Community'],['nb','Nearby'],['fo','Following'],['fy','For You']];
buildFeed=function(){let ps=allPosts();if(feedTab==='fo')ps=ps.filter(p=>p.uid==='me'||S.following[p.uid]||S.subs[p.ch]);else if(feedTab==='co')ps=ps.filter(p=>p.ch);else if(feedTab==='nb')ps=[...ps].reverse();
 const ads=adsList(),out=[];let ai=0;ps.forEach((p,i)=>{out.push(p);if((i+1)%4===0&&ads.length){out.push({ad:1,...ads[ai%ads.length],_k:'a'+i});ai++}});return out};
renderHome=function(){const el=$('#tab-home');feedList=buildFeed();
 el.innerHTML=`<div class="homebar"><button class="livebtn" data-a="live">LIVE</button><div class="tabs">${FT.map(([k,l])=>`<button data-a="ftab" data-v="${k}" class="${feedTab===k?'on':''}">${l}</button>`).join('')}</div><button class="ib" data-a="goSearch">${ic('search')}</button></div><div id="feed">${feedList.length?feedList.map(reel).join(''):`<div class="empty" style="padding-top:35%">${logo('',70)}<p>Nothing here yet.<br>Follow creators from <b>Search</b>.</p></div>`}</div>`;observe()};
reel=function(p){if(p.ad)return adReel(p);
 const u=usr(p.uid),li=S.liked[p.id],sv=S.saved[p.id],fo=S.following[p.uid]||p.uid==='me';
 const cm=(S.comments[p.id]||[]).length+(p.cm||0),likes=(p.likes||0)+(li?1:0),svc=Math.round((p.likes||0)/9)+(sv?1:0);
 return `<section class="reel" data-id="${p.id}"><div class="frame" data-a="tap">${media(p)}<div class="scrim"></div>
 <div class="meta"><b data-a="user" data-id="${p.uid}">${esc(u.name)}</b>${p.ch?` <small style="opacity:.8">· ${esc(chan(p.ch)?.name||'')}</small>`:''}<div class="cap">${esc(p.cap)}</div><div class="snd">${ic('music')}<span>${esc(p.snd||'Original sound')}</span></div></div>
 <div class="rail"><div class="avwrap" data-a="user" data-id="${p.uid}"><div class="av d">${ini(u.name)}</div>${fo?'':`<span class="fp" data-a="follow" data-id="${p.uid}">${ic('plus')}</span>`}</div>
 <button data-a="like" data-id="${p.id}" class="${li?'on':''}">${ic('heart')}<span>${fmt(likes)}</span></button>
 <button data-a="comments" data-id="${p.id}">${ic('msg')}<span>${fmt(cm)}</span></button>
 <button data-a="save" data-id="${p.id}" class="${sv?'on':''}">${ic('bm')}<span>${fmt(svc)}</span></button>
 <button data-a="share" data-id="${p.id}">${ic('share')}<span>${fmt(p.sh||0)}</span></button><div class="disc"></div></div></div></section>`};
drawNav=function(){const t=[['home','home','Home'],['chats','users','Friends'],['create','plus',''],['inbox','msg','Inbox'],['profile','user','Profile']];
 $('#nav').innerHTML=t.map(([k,i,l])=>k==='create'?`<button class="plus" data-a="create"><span>${ic('plus')}</span></button>`:`<button class="${cur===k?'on':''}" data-a="nav" data-v="${k}">${ic(i)}<span>${l}</span>${k==='inbox'&&cur!=='inbox'?'<i class="dot">1</i>':''}</button>`).join('');$('#nav').classList.toggle('dk',cur==='home')};
const _nav3=nav;nav=function(k){_nav3(k);if(k==='chats')ensureNum(()=>{})};
/* ---- My number + presence (receives calls & messages) ---- */
let PRES=null;
function numSheet(){sheet('Your phone number',`<p class="mut" style="font-size:13px">Friends reach you with this number while Caydiid is open. It is not verified.</p><input id="mn" type="tel" placeholder="+252 61 000 0000" value="${esc(S.me.phone||'')}" style="width:100%;height:46px;border-radius:12px;padding:0 14px;background:var(--card);border:1.5px solid var(--line)"><button class="btn w" data-a="saveNum" style="margin-top:10px">Save</button>`)}
function ensureNum(cb){if(S.me&&digits(S.me.phone).length>=6){presence();return cb()}ensureNum.cb=cb;numSheet()}
function presence(){if(PRES||!pj()||!S.me||digits(S.me.phone).length<6)return;
 const p=PRES=new Peer('cdd-n'+digits(S.me.phone));
 p.on('error',e=>{if(e.type==='unavailable-id'){toast('This number is online on another device');PRES=null}else if(e.type==='peer-unavailable')toast('Contact is offline right now')});
 p.on('connection',c=>c.on('data',d=>incoming(d)));p.on('call',ring);p.on('disconnected',()=>{try{p.reconnect()}catch(e){}})}
async function incoming(d){const num=digits(d.from);if(!num)return;const id='k'+num;
 if(!S.contacts.find(c=>c.id===id))S.contacts.push({id,name:d.n||'+'+num,phone:'+'+num});
 const m={me:0,ts:Date.now()};if(d.v){m.v=await vsave(new Blob([d.buf],{type:d.type||'audio/webm'}));m.d=d.d}else if(d.e)m.e=String(d.e).slice(0,8);else m.t=String(d.t||'').slice(0,2000);
 (S.chats[id]=S.chats[id]||[]).push(m);save();const pg=$$('#pages .page').find(p=>p._id===id);pg?pg._draw():toast('💬 '+(d.n||num));if(cur==='chats')chatList()}
function deliver(id,m){if(id[0]!=='k')return;if(!PRES)return toast('Saved on this device (messaging service offline)');
 const c=PRES.connect('cdd-n'+id.slice(1),{reliable:true}),t=setTimeout(()=>{c.open||toast('Not delivered — contact is offline')},6000);
 c.on('open',()=>{c.send({...m,n:S.me.name,from:digits(S.me.phone)});setTimeout(()=>c.close(),2500)});c.on('error',()=>{})}
const _cp=chatPage;chatPage=function(id,wa){_cp(id,wa);if(!wa||id[0]!=='k')return;const d=$('.page:last-child'),f=$('form',d),old=f.onsubmit;f.onsubmit=e=>{const t=$('input',d).value.trim();old(e);t&&deliver(id,{t})}};
/* ---- Calls ---- */
const getMedia=v=>navigator.mediaDevices.getUserMedia({audio:true,video:v?{facingMode:'user'}:false});
function callPage(t,s){const d=push(bar(t)+`<div class="rtc" style="flex:1;height:auto"><video class="rv" autoplay playsinline></video><video class="pip hid" autoplay muted playsinline></video><div class="callbar"><button class="hang" data-a="hang">End</button></div></div>`);
 if(s&&s.getVideoTracks().length){const p=$('.pip',d);p.srcObject=s;p.classList.remove('hid')}return d}
function wireCall(d,call,s){d._s=s;call.on('stream',r=>{$('.rv',d).srcObject=r});call.on('close',()=>d.isConnected&&pop());d.addEventListener('close',()=>{try{call.close()}catch(e){}stopStream(d)})}
function ring(call){const nm=call.metadata?.name||'Someone',v=call.metadata?.video;
 const d=push(`<div class="ringing"><div class="av lg" style="margin:auto">${ini(nm)}</div><h2>${esc(nm)}</h2><p class="mut">Incoming ${v?'video':'voice'} call…</p><div class="rbtns"><button class="btn o" data-a="decline">Decline</button><button class="btn" data-a="accept">Accept</button></div></div>`);
 d._ring=call;d.addEventListener('close',()=>{d._ring&&d._ring.close()})}
async function startCall(id,video){if(id[0]!=='k')return toast('Add this person as a contact with a phone number to call');
 ensureNum(async()=>{if(!PRES)return toast('Calling service unavailable (check internet)');let s;try{s=await getMedia(video)}catch(e){return toast('Camera/mic permission needed (HTTPS)')}
  const d=callPage('Calling '+cinfo(id).name+'…',s);wireCall(d,PRES.call('cdd-n'+id.slice(1),s,{metadata:{name:S.me.name,video}}),s)})}
/* ---- Live (no codes) ---- */
const dummy=()=>{const c=document.createElement('canvas');c.width=c.height=2;c.getContext('2d').fillRect(0,0,2,2);const v=c.captureStream(1);try{const ac=new AudioContext(),x=ac.createMediaStreamDestination();x.stream.getAudioTracks().forEach(t=>v.addTrack(t))}catch(e){}return v};
let livePage=(t,top)=>push(bar(t)+`<div class="cam" style="flex:1"><video class="rv" autoplay ${top?'muted':''} playsinline style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain"></video><div style="position:absolute;top:10px;left:56px;font-size:13px"><span class="livebadge">LIVE</span> ${top?'<span class="vc">0</span> watching':''}</div><div class="livechat"></div>${top?`<div class="callbar"><button class="btn s" data-a="shareLive">Share link</button><button class="hang" data-a="hang">End</button></div>`:''}</div><form class="composer cmc"><input placeholder="Say something…" autocomplete="off"><button class="ib">${ic('send')}</button></form>`);
async function goLiveNow(){if(!pj())return toast('Network library not loaded — check your internet');let s;try{s=await getMedia(1)}catch(e){return toast('Camera/mic permission needed (HTTPS)')}
 const d=livePage('Live',1);d._s=s;$('.rv',d).srcObject=s;const p=new Peer('cdd-live-'+slug(S.me.handle)),calls=new Set(),conns=[],vc=()=>$('.vc',d).textContent=calls.size;
 p.on('error',e=>{if(e.type==='unavailable-id'){toast('You are already live on another device');d.isConnected&&pop()}});
 p.on('call',c=>{c.answer(s);calls.add(c);vc();c.on('close',()=>{calls.delete(c);vc()})});
 p.on('connection',c=>{conns.push(c);c.on('data',m=>{chatAdd(d,m);conns.forEach(x=>x!==c&&x.open&&x.send(m))})});
 d.addEventListener('close',()=>{p.destroy();stopStream(d)});
 $('form',d).onsubmit=e=>{e.preventDefault();const i=$('input',d),t=i.value.trim();if(!t)return;const m={n:S.me.name,t};chatAdd(d,m);conns.forEach(x=>x.open&&x.send(m));i.value=''}}
function watchLive(h){h=slug(h);if(!h)return;if(!pj())return toast('Network library not loaded — check your internet');
 const d=livePage('@'+h,0),p=new Peer(),hid='cdd-live-'+h;let c;d.addEventListener('close',()=>p.destroy());
 p.on('error',e=>{if(e.type==='peer-unavailable'){toast('@'+h+' is not live right now');d.isConnected&&pop()}});
 p.on('open',()=>{const call=p.call(hid,dummy());call.on('stream',r=>{$('.rv',d).srcObject=r});call.on('close',()=>{toast('Live ended');d.isConnected&&pop()});c=p.connect(hid,{reliable:true});c.on('data',m=>chatAdd(d,m))});
 $('form',d).onsubmit=e=>{e.preventDefault();const i=$('input',d),t=i.value.trim();if(!t)return;const m={n:S.me.name,t};chatAdd(d,m);c&&c.open&&c.send(m);i.value=''}}
const liveSheet=()=>sheet('Live',`<button class="btn w" data-a="goLive">Go live now</button><div class="sec">Watch someone</div><div style="display:flex;gap:8px"><input id="lh" placeholder="username" style="flex:1;min-width:0;height:44px;border-radius:22px;padding:0 16px;background:var(--card);border:1.5px solid var(--line)"><button class="btn" data-a="watchGo">Watch</button></div>`);
Object.assign(A,{
 live:liveSheet,joinLive:liveSheet,goLive(){closeSheet();popAll();goLiveNow()},watchGo(){const v=$('#lh').value;closeSheet();watchLive(v)},
 shareLive(){const u=location.href.split('#')[0]+'#live='+slug(S.me.handle);navigator.share?navigator.share({title:'Watch my live on Caydiid',url:u}).catch(()=>{}):(navigator.clipboard?.writeText(u),toast('Live link copied'))},
 call(el){const d=el.closest('.page');startCall(d._id,el.dataset.v==='video')},hang:()=>pop(),decline:()=>pop(),
 async accept(el){const d=el.closest('.page'),call=d._ring;let s;try{s=await getMedia(call.metadata?.video)}catch(e){toast('Permission needed');return pop()}
  d._ring=null;call.answer(s);const cp=callPage(call.metadata?.name||'Call',s);wireCall(cp,call,s);d.remove()},
 saveNum(){const v=$('#mn').value.trim();if(digits(v).length<6)return toast('Enter a valid number');S.me.phone=v;save();PRES&&PRES.destroy();PRES=null;closeSheet();presence();const cb=ensureNum.cb;ensureNum.cb=null;cb&&cb()},editNum:numSheet,
 micMsg(el){const d=el.closest('.page');mic(el,async(b,dur)=>{const k=await vsave(b);S.chats[d._id].push({v:k,d:dur,me:1,ts:Date.now()});save();d._draw();deliver(d._id,{v:1,d:dur,buf:await b.arrayBuffer(),type:b.type})})},
 emoMsg(el){const d=el.closest('.page');emoToggle(el.closest('form'),e=>{S.chats[d._id].push({e,me:1,ts:Date.now()});save();d._draw();deliver(d._id,{e})})}});
SETS[0][1].push(['nv','editNum','My phone number','Used for calls and messages']);
if(S.me){renderHome();drawNav();presence();if(location.hash.startsWith('#live='))setTimeout(()=>watchLive(location.hash.slice(6)),700)}
