'use strict';
/* ===== Caydiid v1.4: stay-in-place on refresh, camera mirror fix, TikTok-style LIVE setup ===== */
S.ui=S.ui||{};if(S.set.mirror===undefined)S.set.mirror=1;
const root=document.documentElement,mirrorApply=()=>root.classList.toggle('mirror',S.set.mirror!==0);mirrorApply();
/* ---- 1. Persistence ---- */
if(S.ui.ft)feedTab=S.ui.ft;
const keep=(o,mk)=>function(...a){S.ui.pg=mk(...a);save();return o.apply(this,a)};
openUser=keep(openUser,id=>['user',id]);openChan=keep(openChan,id=>['chan',id]);openPost=keep(openPost,id=>['post',id]);adsPage=keep(adsPage,()=>['ads']);
settings=keep(settings,()=>['set']);A.settings=settings;chatPage=keep(chatPage,(id,wa)=>['chat',id,wa]);
const _pop=pop,_popAll=popAll;
pop=function(){_pop();setTimeout(()=>{if(!$('#pages').children.length){S.ui.pg=null;save()}},320)};
popAll=function(){_popAll();S.ui.pg=null};
const _nav4=nav;nav=function(k){_nav4(k);S.ui.tab=k;save()};
const _ft=A.ftab;A.ftab=el=>{_ft(el);S.ui.ft=feedTab;save()};
let _st;document.addEventListener('scroll',e=>{const f=e.target;if(!f||f.id!=='feed')return;clearTimeout(_st);_st=setTimeout(()=>{const r=f.children[Math.round(f.scrollTop/f.clientHeight)];if(r&&r.dataset.id){S.ui.reel=r.dataset.id;save()}},300)},true);
const until=Date.now()+3000,_rh4=renderHome;
renderHome=function(){_rh4();const r=S.ui.reel&&Date.now()<until&&$(`.reel[data-id="${S.ui.reel}"]`);if(r)r.scrollIntoView()};
function restore(){if(!S.me)return;const u=S.ui,g=u.pg;if(u.tab&&u.tab!=='home')nav(u.tab);if(!g)return;
 try{({chat:()=>chatPage(g[1],g[2]),user:()=>openUser(g[1]),chan:()=>chan(g[1])&&openChan(g[1]),post:()=>openPost(g[1]),ads:()=>adsPage(),set:()=>settings(),watch:()=>watchLive(g[1]),livehost:()=>autoLive()})[g[0]]()}catch(e){}}
addEventListener('load',()=>setTimeout(restore,700));
/* ---- 2. Camera mirror (selfie view like TikTok; viewers/callee see the true image) ---- */
const _cpg=callPage;callPage=function(t,s){const d=_cpg(t,s);$('.pip',d).classList.add('self');$('.callbar',d).insertAdjacentHTML('afterbegin','<button class="btn s o" data-a="mirrorTog">Mirror</button>');return d};
const _lp=livePage;livePage=function(t,top){const d=_lp(t,top);if(top)$('.rv',d).classList.add('self');return d};
const _ca=chatAdd;chatAdd=function(d,m){if(m.sys){const f=$('form',d);f&&f.classList.toggle('hid',!m.chat);m.title&&_ca(d,{n:'📢',t:m.title});return}_ca(d,m)};
A.mirrorTog=()=>{S.set.mirror=S.set.mirror===0?1:0;save();mirrorApply();toast(S.set.mirror?'Mirror on':'Mirror off')};
/* ---- 3. LIVE setup ---- */
const LS=()=>S.set.live=Object.assign({title:'',chat:1,mic:1,q:720,goal:0,fx:'none',smooth:0,bright:100,mode:'cam'},S.set.live||{});
const FX={none:'',bw:'grayscale(1)',warm:'sepia(.35) saturate(1.2)',cool:'hue-rotate(-15deg) saturate(1.1)',vivid:'saturate(1.7) contrast(1.1)',vintage:'sepia(.6) contrast(.9)'};
const fstr=()=>{const l=LS();return `${FX[l.fx]} brightness(${l.bright}%) ${l.smooth?`blur(${l.smooth*.35}px)`:''}`.trim()};
const applyF=()=>$$('.lv,.rv.self').forEach(v=>v.style.filter=fstr());
const lstream=(face,l)=>navigator.mediaDevices.getUserMedia({audio:true,video:l.mode==='voice'?false:{facingMode:face,height:{ideal:l.q}}});
const tool=(a,i,l)=>`<button class="tl" data-a="${a}"><span>${i}</span>${l}</button>`;
async function liveSetup(){if(!pj())return toast('Network library not loaded — check your internet');const l=LS();
 const d=push(`<div class="lsu"><video class="lv self" autoplay muted playsinline></video><div class="lsvo hid"><div class="av lg">${ini(S.me.name)}</div><p>Voice chat — audio only</p></div><button class="ib lsx" data-a="lsClose">${ic('x')}</button>
 <div class="tools">${tool('lsFlip',ic('flip'),'Flip')}${tool('lsBeauty','🪄','Beautify')}${tool('lsFx','✨','Effects')}${tool('lsSet',ic('set'),'Settings')}${tool('shareLive',ic('share'),'Share')}${tool('lsInter',ic('msg'),'Interact')}${tool('ads','🔥','Promote')}${tool('lsMic','🎙️','Mic')}</div>
 <div class="lscard"><div class="lsrow"><div class="av sm">${ini(S.me.name)}</div><input id="lt" placeholder="Add a title" maxlength="60" value="${esc(l.title)}"><button class="lsgoal" data-a="lsGoal">🎯 LIVE goal${l.goal?' '+l.goal:''}</button></div><button class="golive" data-a="lsGo">Go LIVE</button></div>
 <div class="lsmodes"><button data-a="lsMode" data-v="voice" class="${l.mode==='voice'?'on':''}">🎙️ Voice chat</button><button data-a="lsMode" data-v="cam" class="${l.mode==='cam'?'on':''}">📷 Device camera</button></div>
 <div class="lstabs"><button data-a="lsPost">POST</button><b>LIVE</b><button data-a="lsCreate">CREATE</button></div></div>`);
 d.addEventListener('close',()=>stopStream(d));d._face='user';await lsStart(d)}
async function lsStart(d){stopStream(d);const l=LS();try{d._s=await lstream(d._face,l)}catch(e){toast('Camera/mic permission needed (HTTPS)');return}
 const v=$('.lv',d);v.srcObject=l.mode==='voice'?null:d._s;v.classList.toggle('rear',d._face!=='user');v.classList.toggle('hid',l.mode==='voice');$('.lsvo',d).classList.toggle('hid',l.mode!=='voice');applyF();d._s.getAudioTracks().forEach(t=>t.enabled=!!l.mic)}
const optRow=(k,t,s)=>`<div class="row click" data-a="lsOpt" data-k="${k}"><div class="grow"><span class="nm">${t}</span><small>${s}</small></div></div>`;
const setSheet=()=>{const l=LS();sheet('LIVE settings',optRow('chat','Who can comment',l.chat?'Everyone':'Off')+optRow('mirror','Mirror my camera (selfie view)',S.set.mirror?'On':'Off')+optRow('mic','Microphone',l.mic?'On':'Muted')+optRow('q','Video quality',l.q+'p'))};
function pipe(src,d){const v=document.createElement('video');v.srcObject=src;v.muted=true;v.playsInline=true;v.style.cssText='position:fixed;opacity:0;width:2px;height:2px;pointer-events:none';document.body.append(v);v.play().catch(()=>{});
 const c=document.createElement('canvas'),x=c.getContext('2d');c.width=720;c.height=1280;
 const t=setInterval(()=>{if(!v.videoWidth)return;const s=Math.max(c.width/v.videoWidth,c.height/v.videoHeight),w=v.videoWidth*s,h=v.videoHeight*s;x.filter=fstr()||'none';x.drawImage(v,(c.width-w)/2,(c.height-h)/2,w,h)},33);
 const out=c.captureStream(30);src.getAudioTracks().forEach(a=>out.addTrack(a));d._pv=v;d._pt=t;return out}
function startLive(raw){const l=LS(),id='cdd-live-'+slug(S.me.handle),d=livePage('Live',1);S.ui.pg=['livehost'];save();
 d._s=raw;d._face=d._face||'user';const rv=$('.rv',d);l.mode==='voice'?rv.classList.add('hid'):(rv.srcObject=raw);applyF();
 const out=l.mode==='voice'?raw:pipe(raw,d),calls=new Set(),conns=[];let P;
 const upd=()=>{$('.vc',d).textContent=calls.size+(l.goal?' / '+l.goal:'')};upd();
 d.querySelector('.cam').insertAdjacentHTML('beforeend',`<div class="hud">${l.title?esc(l.title):''}</div>`);
 $('.callbar',d).insertAdjacentHTML('afterbegin',`<button class="btn s o" data-a="lsFlipLive">Flip</button><button class="btn s o" data-a="lsMicLive">Mic</button><button class="btn s o" data-a="lsFx">Effects</button>`);
 const host=n=>{P=new Peer(id);
  P.on('error',e=>{if(e.type==='unavailable-id'){P.destroy();if(n<6)setTimeout(()=>d.isConnected&&host(n+1),2500);else{toast('You are already live on another device');d.isConnected&&pop()}}});
  P.on('call',c=>{c.answer(out);calls.add(c);upd();c.on('close',()=>{calls.delete(c);upd()})});
  P.on('connection',c=>{conns.push(c);c.on('open',()=>c.send({sys:'cfg',chat:l.chat,title:l.title}));c.on('data',m=>{if(!l.chat||m.sys)return;chatAdd(d,m);conns.forEach(x=>x!==c&&x.open&&x.send(m))})})};host(0);
 d.addEventListener('close',()=>{P&&P.destroy();stopStream(d);clearInterval(d._pt);d._pv&&d._pv.remove()});
 $('form',d).onsubmit=e=>{e.preventDefault();const i=$('input',d),t=i.value.trim();if(!t)return;const m={n:S.me.name,t};chatAdd(d,m);conns.forEach(x=>x.open&&x.send(m));i.value=''}}
async function autoLive(){if(!pj())return;try{startLive(await lstream('user',LS()))}catch(e){toast('Live ended — permission needed to resume');S.ui.pg=null;save()}}
const pg=()=>$('#pages .page:last-child');
Object.assign(A,{
 goLive(){closeSheet();popAll();liveSetup()},
 lsClose(el){pop()},lsFlip:async el=>{const d=el.closest('.page');d._face=d._face==='user'?'environment':'user';await lsStart(d)},
 async lsFlipLive(el){const d=el.closest('.page');d._face=d._face==='user'?'environment':'user';const l=LS();try{const n=await lstream(d._face,l);stopStream(d);d._s=n;if(d._pv)d._pv.srcObject=n;$('.rv',d).srcObject=n;$('.rv',d).classList.toggle('rear',d._face!=='user')}catch(e){toast('Cannot switch camera')}},
 lsMicLive(el){const d=el.closest('.page'),l=LS();l.mic=l.mic?0:1;save();d._s.getAudioTracks().forEach(t=>t.enabled=!!l.mic);toast(l.mic?'Mic on':'Mic muted')},
 lsBeauty(){const l=LS();sheet('Beautify',`<div class="sec">Smooth</div><input type="range" id="bsm" min="0" max="5" step="1" value="${l.smooth}" style="width:100%"><div class="sec">Brightness</div><input type="range" id="bbr" min="80" max="140" value="${l.bright}" style="width:100%">`)},
 lsFx(){const l=LS();sheet('Effects',`<div class="chips">${Object.keys(FX).map(k=>`<button class="chip ${l.fx===k?'on':''}" data-a="lsFxSet" data-v="${k}">${k==='none'?'Normal':k[0].toUpperCase()+k.slice(1)}</button>`).join('')}</div>`)},
 lsFxSet(el){LS().fx=el.dataset.v;save();applyF();A.lsFx()},
 lsSet:setSheet,lsInter(){const l=LS();l.chat=l.chat?0:1;save();toast(l.chat?'Viewers can comment':'Comments off')},
 lsMic(el){const d=el.closest('.page'),l=LS();l.mic=l.mic?0:1;save();d._s&&d._s.getAudioTracks().forEach(t=>t.enabled=!!l.mic);toast(l.mic?'Mic on':'Mic muted')},
 lsOpt(el){const k=el.dataset.k,l=LS();if(k==='mirror'){S.set.mirror=S.set.mirror?0:1;mirrorApply()}else if(k==='q')l.q=l.q===480?720:l.q===720?1080:480;else l[k]=l[k]?0:1;save();setSheet()},
 lsGoal(){sheet('LIVE goal',`<div class="chips">${[0,10,50,100,500,1000].map(n=>`<button class="chip" data-a="lsGoalSet" data-v="${n}">${n?n+' viewers':'No goal'}</button>`).join('')}</div>`)},
 lsGoalSet(el){LS().goal=+el.dataset.v;save();closeSheet();const b=$('.lsgoal',pg());b&&(b.textContent='🎯 LIVE goal'+(LS().goal?' '+LS().goal:''))},
 async lsMode(el){const l=LS();l.mode=el.dataset.v;save();const d=el.closest('.page');$$('.lsmodes button',d).forEach(b=>b.classList.toggle('on',b.dataset.v===l.mode));await lsStart(d)},
 lsGo(el){const d=el.closest('.page'),l=LS();l.title=$('#lt',d).value.trim();save();const raw=d._s;if(!raw)return toast('Camera/mic not ready');d._s=null;d.remove();startLive(raw)},
 lsPost(){popAll();camPage('')},lsCreate(){popAll();createMenu()}});
document.addEventListener('input',e=>{const l=LS();if(e.target.id==='bsm'){l.smooth=+e.target.value;applyF();save()}if(e.target.id==='bbr'){l.bright=+e.target.value;applyF();save()}});
