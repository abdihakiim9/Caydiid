'use strict';
/* ===== Caydiid v2: sign-up with e-mail code, login, session ===== */
const API=(window.CAYDIID_API||'').replace(/\/$/,'');
async function api(path,body,tok){try{const r=await fetch(API+'/api/'+path,{method:body?'POST':'GET',headers:Object.assign({'Content-Type':'application/json'},tok?{Authorization:'Bearer '+tok}:{}),body:body?JSON.stringify(body):undefined});let j=null;try{j=await r.json()}catch(e){}if(!j||typeof j!=='object'){const st=r.status;return{status:st,error:(st===404||st===405)?'Server not found ('+st+'). The Caydiid backend is not running at this address. Host the whole folder with Node (node server/server.js) or set CAYDIID_API in index.html.':(st>=500?'Server error ('+st+'). The server is down or crashed. Check the host logs.':'Unexpected reply from server ('+st+').')}}return Object.assign({status:r.status},j)}catch(e){return{status:0,error:'Cannot reach the server. Check your internet.'}}}
const AU={step:'signup',f:{first:'',last:'',dob:'',phone:'',email:'',password:''},ti:null};
const PEND='cdd.pend';
const aerr=m=>{const e=$('#aerr');if(e)e.textContent=m||''};
const maxDob=()=>{const d=new Date();d.setFullYear(d.getFullYear()-13);return d.toISOString().slice(0,10)};
function mkHandle(u){return (String(u.email).split('@')[0].toLowerCase().replace(/[^a-z0-9._]/g,'').slice(0,15))||('user'+Math.floor(Math.random()*9000+1000))}
function authDraw(){
 clearInterval(AU.ti);const w=$('#welcome'),f=AU.f,v=x=>esc(f[x]||'');
 const head=(t,s)=>`${logo('',64)}<h2 style="margin:12px 0 2px;font-size:26px">${t}</h2><p style="margin:0 0 14px;color:var(--mut);font-size:14px">${s}</p>`;
 const pw=`<label class="field"><span>Password</span><div class="pwrap"><input id="au_pw" type="password" autocomplete="${AU.step==='login'?'current-password':'new-password'}" maxlength="128" value="${v('password')}" placeholder="${AU.step==='login'?'Your password':'At least 8 characters'}"><button type="button" class="alink pshow" data-a="auEye">Show</button></div></label>`;
 if(AU.step==='signup')w.innerHTML=`<div class="auth-box">${head('Create your account','Join Caydiid in a minute')}
  <div class="arow"><label class="field"><span>First name</span><input id="au_first" autocomplete="given-name" maxlength="40" value="${v('first')}"></label><label class="field"><span>Last name</span><input id="au_last" autocomplete="family-name" maxlength="40" value="${v('last')}"></label></div>
  <label class="field"><span>Date of birth</span><input id="au_dob" type="date" min="1900-01-01" max="${maxDob()}" value="${v('dob')}"></label>
  <label class="field"><span>Phone number</span><input id="au_phone" type="tel" autocomplete="tel" maxlength="25" placeholder="+252 61 234 5678" value="${v('phone')}"></label>
  <label class="field"><span>Gmail</span><input id="au_email" type="email" autocomplete="email" maxlength="254" placeholder="name@gmail.com" value="${v('email')}"></label>${pw}
  <div class="aerr" id="aerr"></div>
  <div style="width:100%;padding:4px 16px"><button class="btn w" data-a="auSend" data-primary="1">Create account</button></div>
  <p style="margin:14px 0 0;font-size:14px">Already have an account? <button class="alink" data-a="auGo" data-v="login">Log in</button></p>
  <small class="mut" style="display:block;margin-top:10px">By continuing, you accept the Caydiid terms. You must be 13 or older.</small></div>`;
 else if(AU.step==='verify')w.innerHTML=`<div class="auth-box">${head('Check your e-mail',`We sent a 6-digit code to<br><b style="color:var(--fg)">${esc(f.email)}</b>`)}
  <label class="field"><span>Verification code</span><input id="au_code" class="codein" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="••••••"></label>
  <div class="aerr" id="aerr"></div>
  <div style="width:100%;padding:4px 16px"><button class="btn w" data-a="auVerify" data-primary="1">Verify</button></div>
  <p style="margin:14px 0 0"><button class="alink" id="au_rs" data-a="auResend" disabled>Resend code</button></p>
  <p style="margin:8px 0 0"><button class="alink" data-a="auGo" data-v="signup">Change e-mail</button></p>
  <small class="mut" style="display:block;margin-top:10px">Check your Spam folder if you don’t see it. The code lasts 10 minutes.</small></div>`;
 else w.innerHTML=`<div class="auth-box">${head('Welcome back','Log in to Caydiid')}
  <label class="field"><span>E-mail</span><input id="au_email" type="email" autocomplete="email" maxlength="254" placeholder="name@gmail.com" value="${v('email')}"></label>${pw}
  <div class="aerr" id="aerr"></div>
  <div style="width:100%;padding:4px 16px"><button class="btn w" data-a="auLogin" data-primary="1">Log in</button></div>
  <p style="margin:14px 0 0;font-size:14px">New here? <button class="alink" data-a="auGo" data-v="signup">Create an account</button></p></div>`;
 const c=$('#au_code');c&&setTimeout(()=>c.focus(),50)}
function welcome(){const w=$('#welcome');w.classList.remove('hid');w.classList.add('auth');
 let pe=null;try{pe=localStorage.getItem(PEND)}catch(e){}
 if(AU.step==='signup'&&pe&&!AU.f.email){AU.f.email=pe;AU.step='verify';authDraw();cool(0)}else authDraw()}
function cool(s){clearInterval(AU.ti);const b=()=>$('#au_rs');let n=s;const t=()=>{const e=b();if(!e){clearInterval(AU.ti);return}if(n>0){e.disabled=true;e.textContent='Resend code in '+n+'s';n--}else{e.disabled=false;e.textContent='Resend code';clearInterval(AU.ti)}};t();AU.ti=setInterval(t,1000)}
function readForm(){for(const[k,id]of[['first','au_first'],['last','au_last'],['dob','au_dob'],['phone','au_phone'],['email','au_email'],['password','au_pw']]){const e=$('#'+id);if(e)AU.f[k]=e.value}AU.f.first=AU.f.first.trim();AU.f.last=AU.f.last.trim();AU.f.phone=AU.f.phone.trim();AU.f.email=AU.f.email.trim().toLowerCase()}
function busy(btn,on,txt){if(!btn)return;btn.disabled=on;if(on){btn._t=btn.textContent;btn.textContent=txt}else btn.textContent=btn._t||btn.textContent}
function finish(user,token){
 const old=window.__oldMe||{};window.__oldMe=null;
 S.me=Object.assign({bio:'',f:0},old,{name:user.first+' '+user.last,first:user.first,last:user.last,dob:user.dob,phone:user.phone,email:user.email,handle:old.handle||mkHandle(user),verified:true});
 S.tok=token;save();try{localStorage.removeItem(PEND)}catch(e){}
 AU.f={first:'',last:'',dob:'',phone:'',email:'',password:''};AU.step='signup';clearInterval(AU.ti);
 const w=$('#welcome');w.classList.add('hid');w.classList.remove('auth');w.innerHTML='';
 renderHome();drawNav();try{presence()}catch(e){}
 if(location.hash.startsWith('#live='))setTimeout(()=>watchLive(location.hash.slice(6)),700);
 toast('Welcome, '+user.first+' ✓')}
Object.assign(A,{
 auGo(el){readForm();AU.step=el.dataset.v;if(AU.step==='signup')try{localStorage.removeItem(PEND)}catch(e){}authDraw()},
 auEye(el){const i=$('#au_pw');if(!i)return;const s=i.type==='password';i.type=s?'text':'password';el.textContent=s?'Hide':'Show'},
 async auSend(el){readForm();const f=AU.f;
  if(!f.first||!f.last)return aerr('Enter your first and last name');
  if(!f.dob)return aerr('Enter your date of birth');if(f.dob>maxDob())return aerr('You must be at least 13 years old to use Caydiid');
  const pd=f.phone.replace(/\D/g,'');if(!/^\+?[0-9 ()\-]{7,25}$/.test(f.phone)||pd.length<7||pd.length>15)return aerr('Enter a valid phone number, e.g. +252 61 234 5678');
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email))return aerr('Enter a valid e-mail address');
  if(f.password.length<8)return aerr('Password must be at least 8 characters');
  aerr('');busy(el,true,'Sending code…');const r=await api('signup/start',f);busy(el,false);
  if(!r.ok)return aerr(r.error||'Something went wrong. Try again.');
  try{localStorage.setItem(PEND,f.email)}catch(e){}
  AU.step='verify';authDraw();cool(30);if(r.devCode)toast('DEV code: '+r.devCode)},
 async auVerify(el){const c=($('#au_code').value||'').replace(/\D/g,'');if(c.length!==6)return aerr('Enter the 6-digit code');
  aerr('');busy(el,true,'Verifying…');const r=await api('signup/verify',{email:AU.f.email,code:c});busy(el,false);
  if(!r.ok){if(r.status===404||r.status===410){}return aerr(r.error||'Something went wrong. Try again.')}
  finish(r.user,r.token)},
 async auResend(el){aerr('');el.disabled=true;const r=await api('signup/resend',{email:AU.f.email});
  if(!r.ok){aerr(r.error||'Could not resend. Try again.');if(r.status===404){AU.step='signup'}cool(r.status===429?30:0);return}
  toast(r.devCode?'DEV code: '+r.devCode:'New code sent ✓');cool(30)},
 async auLogin(el){readForm();const f=AU.f;if(!f.email||!f.password)return aerr('Enter your e-mail and password');
  aerr('');busy(el,true,'Logging in…');const r=await api('login',{email:f.email,password:f.password});busy(el,false);
  if(!r.ok)return aerr(r.error||'Something went wrong. Try again.');finish(r.user,r.token)}});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.closest&&e.target.closest('#welcome.auth')){const b=$('#welcome [data-primary]');b&&b.click()}});
document.addEventListener('input',e=>{if(e.target.id==='au_code'){const v=e.target.value.replace(/\D/g,'').slice(0,6);e.target.value=v;if(v.length===6)A.auVerify($('#welcome [data-primary]'))}});
/* returning users: just check the saved session quietly; only ask to log in if the server says it is invalid */
if(S.me&&S.me.verified&&S.tok)api('me',null,S.tok).then(r=>{if(r.status===401){window.__oldMe=S.me;S.me=null;delete S.tok;AU.step='login';AU.f.email=(window.__oldMe.email||'');welcome()}});
/* init() may have drawn the old welcome screen before this file loaded; make sure the sign-up screen is the one shown */
if(!S.me)welcome();
