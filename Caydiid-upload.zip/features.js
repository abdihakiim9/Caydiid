'use strict';
/* ===== Caydiid features: voice notes, real WebRTC calls/live, emoji, pro settings ===== */
const FAV='caydiid.fav';let fav;try{fav=JSON.parse(localStorage.getItem(FAV))||['🔥','😂','❤️']}catch(e){fav=['🔥','😂','❤️']}
const favSave=()=>{try{localStorage.setItem(FAV,JSON.stringify(fav))}catch(e){}};
const ALL='😂 ❤️ 🔥 😍 👏 😮 😢 🙏 🎉 💯 😎 🤩 😭 🥰 😡 🤣 👍 👎 💪 🙌 🤝 😴 🤔 😅 🥳 😇 🤯 😱 💔 ✨ 🌹 🎶 👀 🤲 😋 🫶 💥 🏆 🚀 ☕'.split(' ');
const DEFS={nLike:1,nCm:1,nFol:1,nMsg:1,nLive:1,caps:0,dm:1,ph:1,msgw:0,dl:0,cmt:0,lang:0};
for(const[k,v]of Object.entries(DEFS))if(typeof S.set[k]==='undefined'||(k==='cmt'&&typeof S.set[k]!=='number'))S.set[k]=v;
S.savedCm=S.savedCm||{};
const ea=e=>'a'+(e.codePointAt(0)%4);
const bigE=e=>`<span class="big ${ea(e)}">${e}</span>`;
/* --- voice recording --- */
let MR=null;const fmtT=n=>{n=Math.max(0,Math.round(+n||0));return Math.floor(n/60)+':'+String(n%60).padStart(2,'0')};
async function mic(btn,done){
 if(MR){MR.stop();return}
 try{const s=await navigator.mediaDevices.getUserMedia({audio:true}),ch=[],t0=Date.now(),r=new MediaRecorder(s);MR=r;btn.classList.add('recing');const tm=document.createElement('div');tm.className='rect';document.body.append(tm);const tick=()=>{const q=Math.floor((Date.now()-t0)/1000);tm.textContent='● '+fmtT(q);if(q>=300&&MR===r)r.stop()};tick();r._ti=setInterval(tick,250);r._tm=tm;
  r.ondataavailable=e=>e.data.size&&ch.push(e.data);
  r.onstop=()=>{clearInterval(r._ti);r._tm&&r._tm.remove();s.getTracks().forEach(x=>x.stop());btn.classList.remove('recing');MR=null;const d=Math.round((Date.now()-t0)/1000);if(d<1)return toast('Too short — hold a bit longer');done(new Blob(ch,{type:r.mimeType||'audio/webm'}),d)};r.start();toast('Recording… tap again to send')}
 catch(e){toast('Microphone permission needed (use HTTPS)')}}
const vsave=async b=>{const k='v'+Date.now()+Math.random().toString(36).slice(2,6);await idb.put(k,b);return k};
async function hydrate(root){for(const el of $$('[data-vk]',root)){if(el.src)continue;const b=await idb.get(el.dataset.vk);if(b){el.addEventListener('loadedmetadata',()=>{if(el.duration===Infinity||isNaN(el.duration)){const f=()=>{el.removeEventListener('timeupdate',f);el.currentTime=0};el.addEventListener('timeupdate',f);el.currentTime=1e101}},{once:true});el.src=URL.createObjectURL(b)}}}
const vn=(k,d)=>`<div class="vn"><audio controls preload="none" data-vk="${k}"></audio><small>${fmtT(d)}</small></div>`;
/* --- emoji panel with favorites --- */
function emoToggle(comp,onPick){
 let p=comp.previousElementSibling;if(p&&p.classList.contains('emop')){p.remove();return}
 p=document.createElement('div');p.className='emop';let ed=0;
 const b=e=>`<button data-e="${e}" class="big ${ea(e)}">${e}${ed?`<i>${fav.includes(e)?'★':'☆'}</i>`:''}</button>`;
 const draw=()=>{p.innerHTML=`<div class="emh"><b>★ Favorites</b><button class="chip ${ed?'on':''}" data-x="1">${ed?'Done':'Edit'}</button></div><div class="emg">${fav.map(b).join('')||'<small class="mut">Tap Edit, then ☆ to add favorites</small>'}</div><div class="emh"><b>All emoji</b></div><div class="emg">${ALL.map(b).join('')}</div>`};
 p.onclick=ev=>{const t=ev.target.closest('button');if(!t)return;if(t.dataset.x){ed=!ed;draw();return}const e=t.dataset.e;if(ed){fav=fav.includes(e)?fav.filter(x=>x!==e):[...fav,e];favSave();draw()}else onPick(e)};
 draw();comp.before(p)}
/* --- chat --- */
openChat=function(id){const u=usr(id);S.chats[id]=S.chats[id]||[];
 const draw=d=>{const m=$('.msgs',d);m.innerHTML=(S.chats[id].length?S.chats[id]:[{t:'Hey! How are you?',me:0}]).map(x=>`<div class="msg ${x.me?'me':''}">${x.v?vn(x.v,x.d):x.e?bigE(x.e):esc(x.t)}</div>`).join('');hydrate(m);m.scrollTop=1e9};
 push(bar(esc(u.name),`<button class="ib" data-a="call" data-v="voice">📞</button><button class="ib" data-a="call" data-v="video">🎥</button>`)+`<div class="msgs"></div><form class="composer"><button type="button" class="ib" data-a="emoMsg">😊</button><input placeholder="Message…" autocomplete="off"><button type="button" class="ib mic" data-a="micMsg">🎙️</button><button>${ic('send')}</button></form>`,d=>{
  d._id=id;d._draw=()=>draw(d);draw(d);
  $('form',d).onsubmit=e=>{e.preventDefault();const i=$('input',d),t=i.value.trim();if(!t)return;S.chats[id].push({t,me:1});i.value='';save();draw(d)}})};
Object.assign(A,{
 micMsg(el){const d=el.closest('.page');mic(el,async(b,dur)=>{const k=await vsave(b);S.chats[d._id].push({v:k,d:dur,me:1});save();d._draw()})},
 emoMsg(el){const d=el.closest('.page');emoToggle(el.closest('form'),e=>{S.chats[d._id].push({e,me:1});save();d._draw()})},
 call(el){rtcPage(el.dataset.v)},goLive:()=>rtcPage('live'),joinLive(){rtcPage('live');A.rtcJoin($('.page:last-child .sig .btn.o'))}});
/* --- comments: text, voice, big emoji, like, save --- */
let curCm='';
cmHTML=function(id){const list=[...DEMOCM.map(([u,t],i)=>({u,t,i:'d'+i})),...seedCm(id)];
 return list.map(c=>{const u=c.u==='me'?ME():usr(c.u),i=c.i||'x'+id,lk=S.likedCm[i],sv=S.savedCm[i];
  return `<div class="row" style="padding:10px 0"><div class="av sm d">${ini(u.name)}</div><div class="grow" style="white-space:normal"><b style="font-size:13px">@${esc(u.handle)}</b><div style="font-size:14px">${c.v?vn(c.v,c.d):c.e?bigE(c.e):esc(c.t)}</div></div><div class="cma"><button data-a="cmLike" data-i="${i}" class="${lk?'on':''}">${ic('heart')}</button><button data-a="cmSave" data-i="${i}" class="${sv?'on':''}">${ic('bm')}</button>${c.u==='me'?`<button data-a="cmDel" data-i="${i}">${ic('trash')}</button>`:''}</div></div>`}).join('')}
const cmDraw=()=>{const l=$('#cml');if(l){l.innerHTML=cmHTML(curCm);hydrate(l)}};
const addCm=o=>{(S.comments[curCm]=S.comments[curCm]||[]).push({u:'me',i:'c'+Date.now(),...o});save();cmDraw();refreshReelCount(curCm)};
openComments=function(id){curCm=id;
 sheet('Comments',`<div id="cml">${cmHTML(id)}</div><div class="composer cmc" style="position:sticky;bottom:0;background:var(--bg)"><button class="ib" data-a="emoCm">😊</button><input id="cmi" placeholder="Add a comment…" maxlength="200"><button class="ib mic" data-a="micCm">🎙️</button><button class="ib" data-a="sendCm" data-id="${id}">${ic('send')}</button></div>`);hydrate($('#cml'))};
Object.assign(A,{
 sendCm(){const i=$('#cmi'),t=i.value.trim();if(!t)return;addCm({t});i.value=''},
 micCm(el){mic(el,async(b,d)=>addCm({v:await vsave(b),d}))},
 emoCm(el){emoToggle(el.parentElement,e=>addCm({e}))},
 cmLike(el){const i=el.dataset.i;S.likedCm[i]=!S.likedCm[i];save();cmDraw()},
 cmSave(el){const i=el.dataset.i;S.savedCm[i]=!S.savedCm[i];save();cmDraw();toast(S.savedCm[i]?'Comment saved':'Removed from saved')},
 cmDel(el){const l=S.comments[curCm]||[];S.comments[curCm]=l.filter(c=>c.i!==el.dataset.i);save();cmDraw();refreshReelCount(curCm)},
 saved(){const rows=[];for(const[id,l]of Object.entries(S.comments))l.forEach(c=>S.savedCm[c.i]&&rows.push(`<div class="row"><div class="grow" style="white-space:normal">${c.v?'🎙️ Voice comment':c.e?bigE(c.e):esc(c.t)}</div></div>`));
  sheet('Saved comments',rows.join('')||'<div class="empty">Nothing saved yet</div>')}});
/* --- real WebRTC calls & live (peer-to-peer, code exchange) --- */
const ICE={iceServers:[{urls:'stun:stun.l.google.com:19302'}]};
const enc=d=>btoa(unescape(encodeURIComponent(JSON.stringify(d)))),dec=s=>JSON.parse(decodeURIComponent(escape(atob(s.trim()))));
const gather=pc=>new Promise(r=>{if(pc.iceGatheringState==='complete')return r();pc.onicegatheringstatechange=()=>pc.iceGatheringState==='complete'&&r();setTimeout(r,4000)});
function rtcPage(mode){const live=mode==='live';
 const d=push(bar(live?'Live':mode==='video'?'Video call':'Voice call')+`<div class="rtc"><video class="rv" autoplay playsinline></video><video class="pip hid" autoplay muted playsinline></video><div class="livechat"></div></div><div class="sig"><div style="display:flex;gap:8px"><button class="btn w" data-a="rtcHost">${live?'Go live (host)':'Start call'}</button><button class="btn o w" data-a="rtcJoin">${live?'Watch (code)':'Join (code)'}</button></div><div class="sgb"></div><form class="composer rc hid"><input placeholder="Chat…" autocomplete="off"><button>${ic('send')}</button></form></div>`);
 d._m=mode;d._pcs=[];d._dc=[];d.addEventListener('close',()=>{d._pcs.forEach(p=>p.close());stopStream(d)});
 $('.rc',d).onsubmit=e=>{e.preventDefault();const i=$('input',d.querySelector('.rc')),t=i.value.trim();if(!t)return;chatAdd(d,{n:S.me.name,t});d._dc.forEach(c=>c.readyState==='open'&&c.send(JSON.stringify({n:S.me.name,t})));i.value=''}}
function chatAdd(d,m){const b=$('.livechat',d);b.insertAdjacentHTML('beforeend',`<div><b>${esc(m.n)}</b> ${esc(m.t)}</div>`);while(b.children.length>7)b.firstChild.remove()}
async function localMedia(d){if(d._s)return;const v=d._m!=='voice';try{d._s=await navigator.mediaDevices.getUserMedia({audio:true,video:v?{facingMode:'user'}:false});if(v){const p=$('.pip',d);p.srcObject=d._s;p.classList.remove('hid')}}catch(e){toast('Camera/mic permission needed (HTTPS required)');throw e}}
function mkPeer(d){const pc=new RTCPeerConnection(ICE);d._pcs.push(pc);d._s&&d._s.getTracks().forEach(t=>pc.addTrack(t,d._s));
 pc.ontrack=e=>{$('.rv',d).srcObject=e.streams[0]};
 const wire=c=>{d._dc.push(c);c.onopen=()=>$('.rc',d).classList.remove('hid');c.onmessage=e=>chatAdd(d,JSON.parse(e.data))};
 pc.ondatachannel=e=>wire(e.channel);pc.wire=wire;
 pc.onconnectionstatechange=()=>{if(pc.connectionState==='connected')toast('Connected ✓');if(pc.connectionState==='failed')toast('Connection failed (network may need TURN)')};return pc}
const codeBox=(l,v,ro)=>`<label class="field"><span>${l}</span><textarea ${ro?'readonly':''} rows="4" style="font-size:11px;word-break:break-all">${v||''}</textarea></label>`;
Object.assign(A,{
 async rtcHost(el){const d=el.closest('.page');try{await localMedia(d)}catch(e){return}
  const pc=mkPeer(d);pc.wire(pc.createDataChannel('c'));d._last=pc;
  await pc.setLocalDescription(await pc.createOffer({offerToReceiveAudio:true,offerToReceiveVideo:d._m==='video'}));await gather(pc);
  $('.sgb',d).innerHTML=codeBox('1. Send this code to the other person',enc(pc.localDescription),1)+`<button class="btn s o" data-a="copyCode">Copy / share code</button>`+codeBox('2. Paste their reply code here','')+`<button class="btn w" data-a="rtcConnect">Connect</button>${d._m==='live'?'<p class="mut" style="font-size:12px">Each viewer needs their own code. Tap “Go live” again for another viewer.</p>':''}`},
 async rtcConnect(el){const d=el.closest('.page'),v=$('.sgb textarea:not([readonly])',d).value;try{await d._last.setRemoteDescription(dec(v));toast('Connecting…')}catch(e){toast('Invalid code')}},
 rtcJoin(el){const d=el.closest('.page');$('.sgb',d).innerHTML=codeBox('Paste the code you received','')+`<button class="btn w" data-a="rtcAnswer">Create reply code</button>`},
 async rtcAnswer(el){const d=el.closest('.page');try{if(d._m!=='live')await localMedia(d);const pc=mkPeer(d);await pc.setRemoteDescription(dec($('.sgb textarea',d).value));
   await pc.setLocalDescription(await pc.createAnswer());await gather(pc);
   $('.sgb',d).innerHTML=codeBox('Send this reply code back',enc(pc.localDescription),1)+`<button class="btn s o" data-a="copyCode">Copy / share code</button>`}catch(e){toast('Invalid code')}},
 copyCode(el){const t=$('textarea[readonly]',el.closest('.sig')).value;navigator.share?navigator.share({text:t}).catch(()=>{}):(navigator.clipboard?.writeText(t),toast('Code copied'))}});
/* --- Professional settings --- */
const SEL={msgw:['Everyone','Friends','No one'],dl:['Everyone','Friends','No one'],cmt:['Everyone','Friends','No one'],lang:['English']};
const SETS=[['Account',[['nv','editProf','Edit profile'],['nv','newChan','Create channel','Your own channel'],['tog','priv','Private account','Only approved followers see your videos'],['sel','msgw','Who can message me']]],
['Content & display',[['theme'],['sel','lang','Language'],['tog','autoplay','Autoplay'],['tog','sound','Sound on by default'],['tog','saver','Data saver','Lower quality, less data'],['tog','caps','Captions']]],
['Notifications',[['push'],['tog','nLike','Likes'],['tog','nCm','Comments'],['tog','nFol','New followers'],['tog','nMsg','Messages'],['tog','nLive','Live from people you follow']]],
['Privacy & safety',[['sel','cmt','Who can comment'],['sel','dl','Who can download my videos'],['tog','dm','Show activity status'],['tog','ph','Suggest my account to others']]],
['Ads',[['nv','ads','Ads manager','Create, pause or delete'],['tog','pers','Personalized ads'],['nv','resetAds','Reset hidden ads']]],
['Library',[['nv','saved','Saved comments']]],
['Support',[['nv','report','Report a problem'],['nv','terms','Terms & Privacy'],['nv','about','About Caydiid','Version 1.5'],['nv','clear','Clear cache']]],
['',[['nv','logout','Log out (reset)','Deletes local data']]]];
drawSet=function(d){const b=(d||$('.page:last-child')).querySelector('#setbody');if(!b)return;
 b.innerHTML=SETS.map(([t,rows])=>(t?`<div class="sec">${t}</div>`:'<div class="sec"></div>')+rows.map(r=>{const[k,a,l,s]=r;
  if(k==='tog')return tog(a,l,s);if(k==='nv')return nv(a,l,s);
  if(k==='sel')return `<div class="row click" data-a="cyc" data-k="${a}"><div class="grow"><span class="nm">${l}</span><small>${SEL[a][S.set[a]||0]}</small></div>${ic('chev')}</div>`;
  if(k==='theme')return `<div class="row click" data-a="theme"><div class="grow"><span class="nm">Theme</span><small>${{dark:'Dark',light:'Light (white)',auto:'Match device'}[S.set.theme]||'Dark'}</small></div><div class="tog ${S.set.theme==='light'?'on':''}"></div></div>`;
  return `<div class="row click" data-a="push"><div class="grow"><span class="nm">Push notifications</span><small>${typeof Notification!=='undefined'?Notification.permission:'unsupported'}</small></div><div class="tog ${S.set.notif?'on':''}"></div></div>`}).join('')).join('')};
Object.assign(A,{
 cyc(el){const k=el.dataset.k;S.set[k]=((S.set[k]||0)+1)%SEL[k].length;save();drawSet()},
 async push(){if(typeof Notification==='undefined')return toast('Not supported on this browser');
  if(!S.set.notif){const p=await Notification.requestPermission();S.set.notif=p==='granted';if(!S.set.notif)toast('Permission denied')}else S.set.notif=false;save();drawSet()},
 report:()=>sheet('Report a problem',`<textarea id="rp" rows="4" placeholder="What went wrong?" style="width:100%;background:var(--card);border:1.5px solid var(--line);border-radius:12px;padding:12px"></textarea><button class="btn w" data-a="sendRp" style="margin-top:10px">Send</button>`),
 sendRp(){const t=$('#rp').value.trim();if(!t)return;try{const r=JSON.parse(localStorage.getItem('caydiid.reports')||'[]');r.push({t,d:Date.now()});localStorage.setItem('caydiid.reports',JSON.stringify(r))}catch(e){}closeSheet();toast('Thanks, report saved')},
 terms:()=>sheet('Terms & Privacy','<p style="padding:6px 2px;font-size:14px">Your data stays on this device. Be respectful, do not post illegal or harmful content, and only record people with their consent.</p>')});
const _cmu=createMenu;createMenu=function(c){_cmu(c);const b=$('.page:last-child .body');b&&b.insertAdjacentHTML('beforeend',`<div class="bigopt" data-a="joinLive"><div class="ico">${ic('eye')}</div><div><b>Watch a live</b><small>Join with a code</small></div></div>`)};
