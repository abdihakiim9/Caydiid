'use strict';
/* ===== Caydiid — app oo ah sida TikTok, madow & cadaan ===== */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>n>=1e6?(n/1e6).toFixed(1).replace('.0','')+'M':n>=1e3?(n/1e3).toFixed(1).replace('.0','')+'K':''+n;
const ini=n=>(typeof S!=='undefined'&&S&&S.me&&S.me.pic&&n===S.me.name)?`<img class="pic" alt="" src="${S.me.pic}">`:(n||'?').trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase();
const P={home:'<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',search:'<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',plus:'<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',msg:'<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',user:'<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',heart:'<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',share:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>',bm:'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',music:'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',set:'<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',x:'<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',back:'<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',chev:'<polyline points="9 18 15 12 9 6"/>',send:'<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',cam:'<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',up:'<polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/>',live:'<circle cx="12" cy="12" r="2"/><path d="M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14"/>',bell:'<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',users:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',trash:'<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/>',play:'<polygon points="5 3 19 12 5 21 5 3"/>',ad:'<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>',grid:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',check:'<polyline points="20 6 9 17 4 12"/>',lock:'<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',more:'<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',flip:'<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',eye:'<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>'};
const ic=(n,c='')=>`<svg class="ic ${c}" viewBox="0 0 24 24">${P[n]}</svg>`;

/* ---------- Xogta tijaabada ---------- */
const USERS=[
{id:'hodan',name:'Hodan Axmed',handle:'hodan',bio:'Somali food & daily life',f:128400},
{id:'cabdi',name:'Cabdi Nuur',handle:'cabdi.nuur',bio:'Comedy & fun 😂',f:842000},
{id:'sagal',name:'Sagal Beats',handle:'sagal.beats',bio:'Artist | Music',f:56200},
{id:'warsame',name:'Warsame Tech',handle:'warsame',bio:'Tech made simple',f:31900},
{id:'ladan',name:'Ladan Fit',handle:'ladan.fit',bio:'Fitness & health',f:92300},
{id:'yaasiin',name:'Yaasiin Travel',handle:'yaasiin',bio:'Travels in the Horn of Africa',f:210000}];
const CHANNELS=[
{id:'c1',name:'Cunto Soomaali',handle:'cunto',owner:'hodan',bio:'Traditional & modern recipes',subs:45000},
{id:'c2',name:'Majaajilo Toos',handle:'majaajilo',owner:'cabdi',bio:'A laugh every day',subs:320000},
{id:'c3',name:'Tech Soomaali',handle:'techsom',owner:'warsame',bio:'Tech lessons and reviews',subs:18700}];
const POSTS=[
{id:'p1',uid:'hodan',ch:'c1',cap:'Pasta and sauce — the easy way 🍝 #cunto #karis',likes:48200,cm:932,sh:1200,snd:'Original sound · Hodan',bg:0,g:'🍝'},
{id:'p2',uid:'cabdi',ch:'c2',cap:'Markii aabo yidhaahdo "hal daqiiqo ayaan imaanayaa" 😂 #majaajilo',likes:312000,cm:4410,sh:9800,snd:'Original sound · Cabdi',bg:1,g:'😂'},
{id:'p3',uid:'sagal',cap:'New song — part one 🎶 #muusig #caydiid',likes:77300,cm:1210,sh:2300,snd:'New Song · Sagal Beats',bg:2,g:'♪'},
{id:'p4',uid:'warsame',ch:'c3',cap:'3 apps that make your phone easier #tiknoolajiyad',likes:15400,cm:312,sh:890,snd:'Original sound · Warsame',bg:3,g:'</>'},
{id:'p5',uid:'ladan',cap:'10-minute home workout #jimicsi',likes:29100,cm:480,sh:760,snd:'Workout Mix · DJ Nuur',bg:4,g:'💪'},
{id:'p6',uid:'yaasiin',cap:'Lido beach — rainy morning #safar #soomaaliya',likes:101500,cm:2010,sh:5100,snd:'Waves · Nature',bg:5,g:'🌊'},
{id:'p7',uid:'hodan',ch:'c1',cap:'Perfectly soft canjeero 🥞 #cunto',likes:22800,cm:354,sh:410,snd:'Original sound · Hodan',bg:2,g:'🥞'},
{id:'p8',uid:'cabdi',ch:'c2',cap:'When you leave the exam 😅 #majaajilo #dugsi',likes:189000,cm:3100,sh:6700,snd:'Funny Beat · Loop',bg:0,g:'😅'},
{id:'p9',uid:'sagal',cap:'Sound test — what do you think? #muusig',likes:12400,cm:260,sh:180,snd:'New Song · Sagal Beats',bg:3,g:'🎤'}];
const LIVES=[{u:'sagal',t:'Live performance 🎤',v:3600},{u:'cabdi',t:'Q&A',v:12800},{u:'ladan',t:'Group workout',v:940},{u:'yaasiin',t:'Live trip — Hargeysa',v:2210}];
const TAGS=['cunto','majaajilo','muusig','safar','tiknoolajiyad','jimicsi','caydiid','soomaaliya','dugsi','karis'];
const AD0=[
{id:'ad1',brand:'Hormuud Offers',title:'New internet bundle',text:'Get 10GB and unlimited calls this week.',cta:'Buy now',link:'',bg:1,g:'📶',sys:1},
{id:'ad2',brand:'Suuq Online',title:'Everything you need — one place',text:'Fast delivery. 30% off.',cta:'Visit store',link:'',bg:4,g:'🛍️',sys:1}];
const REPLIES=['Thanks! 🙏','Sure 👌','See you soon','Haha 😂','Nice, send me the details','How are you?'];

/* ---------- Xaalad ---------- */
const LSKEY='caydiid.v1';
const def=()=>({me:null,liked:{},saved:{},following:{},subs:{},channels:[],ads:[],posts:[],comments:{},chats:{},hiddenAds:{},likedCm:{},
 set:{theme:'dark',autoplay:true,saver:false,notif:true,priv:false,cmt:'all',pers:true,sound:true}});
let S=(()=>{try{const x=JSON.parse(localStorage.getItem(LSKEY));return x?Object.assign(def(),x,{set:Object.assign(def().set,x.set)}):def()}catch(e){return def()}})();
const save=()=>{try{localStorage.setItem(LSKEY,JSON.stringify(S))}catch(e){}};
const vurl={};
const idb={db:null,open(){return new Promise(r=>{try{const q=indexedDB.open('caydiid',1);q.onupgradeneeded=()=>q.result.createObjectStore('v');q.onsuccess=()=>{this.db=q.result;r()};q.onerror=()=>r()}catch(e){r()}})},
 put(k,v){return new Promise(r=>{try{const t=this.db.transaction('v','readwrite');t.objectStore('v').put(v,k);t.oncomplete=r;t.onerror=r}catch(e){r()}})},
 get(k){return new Promise(r=>{try{const q=this.db.transaction('v').objectStore('v').get(k);q.onsuccess=()=>r(q.result);q.onerror=()=>r()}catch(e){r()}})},
 del(k){return new Promise(r=>{try{const t=this.db.transaction('v','readwrite');t.objectStore('v').delete(k);t.oncomplete=r;t.onerror=r}catch(e){r()}})}};
const ME=()=>({id:'me',name:S.me.name,handle:S.me.handle,bio:S.me.bio,f:S.me.f||0});
const usr=id=>id==='me'?ME():USERS.find(u=>u.id===id)||USERS[0];
const allPosts=()=>[...S.posts,...POSTS];
const chan=id=>[...S.channels,...CHANNELS].find(c=>c.id===id);
const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('on'),2200)};
let applyTheme=()=>{document.documentElement.dataset.theme=S.set.theme;$('meta[name=theme-color]').content=S.set.theme==='dark'?'#000000':'#ffffff'};
const logo=(c='',s=40)=>`<img class="logo ${c}" src="logo.png" width="${s}" height="${s}" alt="Caydiid">`;

/* ---------- Pages / sheets ---------- */
function push(html,mount){const d=document.createElement('div');d.className='page';d.innerHTML=html;$('#pages').append(d);requestAnimationFrame(()=>requestAnimationFrame(()=>d.classList.add('in')));mount&&mount(d);return d}
function pop(){const d=$('#pages').lastElementChild;if(!d)return;d.classList.remove('in');d.dispatchEvent(new Event('close'));setTimeout(()=>d.remove(),250)}
function popAll(){while($('#pages').lastElementChild){const d=$('#pages').lastElementChild;d.dispatchEvent(new Event('close'));d.remove()}}
const bar=(t,r='')=>`<header class="bar"><button class="ib" data-a="back">${ic('back')}</button><h2>${t}</h2><div class="r">${r}</div></header>`;
function sheet(title,html,mount){$('#sheet').innerHTML=`<div class="grab"></div><div class="sh">${title}</div><div class="sb">${html}</div>`;$('#sheet').classList.add('on');$('#sheetbg').classList.add('on');mount&&mount($('#sheet'))}
const closeSheet=()=>{$('#sheet').classList.remove('on');$('#sheetbg').classList.remove('on')};

/* ---------- Welcome ---------- */
function welcome(){const w=$('#welcome');w.classList.remove('hid');
 w.innerHTML=`${logo('',110)}<h1>Caydiid</h1><p>Short videos. Your voice.</p>
 <label class="field"><span>Your name</span><input id="wn" placeholder="Example: Alex Smith" maxlength="30"></label>
 <label class="field"><span>Username</span><input id="wh" placeholder="mubaarig" maxlength="20"></label>
 <div style="width:100%;padding:8px 16px"><button class="btn w" data-a="start">Start</button></div>
 <small class="mut" style="margin-top:8px">By continuing, you accept the Caydiid terms.</small>`}

/* ---------- Home / feed ---------- */
let feedTab='fy',feedList=[];
function adsList(){return [...S.ads.filter(a=>a.active),...AD0].filter(a=>!S.hiddenAds[a.id])}
function buildFeed(){
 let ps=allPosts();if(feedTab==='fo')ps=ps.filter(p=>p.uid==='me'||S.following[p.uid]||S.subs[p.ch]);
 const ads=adsList(),out=[];let ai=0;
 ps.forEach((p,i)=>{out.push(p);if((i+1)%4===0&&ads.length){out.push({ad:1,...ads[ai%ads.length],_k:'a'+i});ai++}});
 if(!out.length)return[];return out}
function renderHome(keep){
 const el=$('#tab-home');feedList=buildFeed();
 el.innerHTML=`<div class="homebar"><button class="ib" data-a="live">${ic('live')}</button>
  <div class="tabs"><button data-a="ftab" data-v="fo" class="${feedTab==='fo'?'on':''}">Following</button><button data-a="ftab" data-v="fy" class="${feedTab==='fy'?'on':''}">For You</button></div>
  <button class="ib" data-a="goSearch">${ic('search')}</button></div>
  <div id="feed">${feedList.length?feedList.map(reel).join(''):`<div class="empty" style="padding-top:35%">${logo('',70)}<p>You are not following anyone yet.<br>Visit <b>Search</b> to find creators.</p></div>`}</div>`;
 observe()}
function media(p){const u=vurl[p.id];
 return u?`<video src="${u}" loop playsinline preload="auto"></video>`:`<div class="bgart b${p.bg%6}"><div class="glyph">${esc(p.g||'C')}</div><i class="prog"></i></div>`}
function reel(p){
 if(p.ad)return adReel(p);
 const u=usr(p.uid),li=S.liked[p.id],sv=S.saved[p.id],fo=S.following[p.uid]||p.uid==='me';
 const cm=(S.comments[p.id]||[]).length+(p.cm||0),likes=(p.likes||0)+(li&&!p._l?1:0);
 return `<section class="reel" data-id="${p.id}"><div class="frame" data-a="tap">${media(p)}<div class="scrim"></div>
 <div class="meta"><b data-a="user" data-id="${p.uid}">@${esc(u.handle)}</b>${p.ch?` <small style="opacity:.8">· ${esc(chan(p.ch)?.name||'')}</small>`:''}<div class="cap">${esc(p.cap)}</div><div class="snd">${ic('music')}<span>${esc(p.snd||'Original sound')}</span></div></div>
 <div class="rail">
  <div class="avwrap" data-a="user" data-id="${p.uid}"><div class="av d">${ini(u.name)}</div>${fo?'':`<span class="fp" data-a="follow" data-id="${p.uid}">${ic('plus')}</span>`}</div>
  <button data-a="like" data-id="${p.id}" class="${li?'on':''}">${ic('heart')}<span>${fmt(likes)}</span></button>
  <button data-a="comments" data-id="${p.id}">${ic('msg')}<span>${fmt(cm)}</span></button>
  <button data-a="save" data-id="${p.id}" class="${sv?'on':''}">${ic('bm')}<span>${sv?'Saved':'Save'}</span></button>
  <button data-a="share" data-id="${p.id}">${ic('share')}<span>${fmt(p.sh||0)}</span></button>
  <div class="disc"></div></div></div></section>`}
function adReel(a){return `<section class="reel" data-ad="${a.id}"><div class="frame" data-a="tap"><div class="bgart b${(a.bg||1)%6}"><div class="glyph">${esc(a.g||'C')}</div></div><div class="scrim"></div>
 <span class="adtag">AD</span><button class="ib" data-a="adMenu" data-id="${a.id}" style="position:absolute;top:6px;right:6px;color:#fff">${ic('more')}</button>
 <div class="adinfo"><div class="row" style="padding:0"><div class="av sm">${ini(a.brand)}</div><b>${esc(a.brand)}</b></div><h3>${esc(a.title)}</h3><p>${esc(a.text)}</p></div>
 <button class="adcta" data-a="adClick" data-id="${a.id}">${esc(a.cta||'Learn more')}</button></div></section>`}
let io;
function observe(){
 io&&io.disconnect();const feed=$('#feed');if(!feed)return;
 io=new IntersectionObserver(es=>es.forEach(e=>{
  const v=$('video',e.target);
  if(e.isIntersecting){
   if(v&&S.set.autoplay){v.muted=!S.set.sound;v.play().catch(()=>{v.muted=true;v.play().catch(()=>{})})}
   const ad=e.target.dataset.ad;if(ad){const x=S.ads.find(a=>a.id===ad);if(x&&!e.target._seen){e.target._seen=1;x.imp=(x.imp||0)+1;save()}}
  }else if(v)v.pause()}),{root:feed,threshold:.65});
 $$('.reel',feed).forEach(r=>io.observe(r))}
function burst(f,x,y){const b=document.createElement('div');b.className='pburst';b.innerHTML=ic('heart');const r=f.getBoundingClientRect();b.style.left=(x-r.left-45)+'px';b.style.top=(y-r.top-45)+'px';f.append(b);setTimeout(()=>b.remove(),800)}
function toggleLike(id){S.liked[id]=!S.liked[id];if(!S.liked[id])delete S.liked[id];save();refreshReel(id)}
function refreshReel(id){const r=$(`.reel[data-id="${id}"]`);const p=allPosts().find(x=>x.id===id);if(!r||!p)return;const t=document.createElement('div');t.innerHTML=reel(p);const nr=t.firstElementChild;const ov=$('video',r),nv=$('video',nr);if(ov&&nv){nv.replaceWith(ov)}r.replaceWith(nr);io&&io.observe(nr)}

/* ---------- Comments ---------- */
const seedCm=id=>S.comments[id]||[];
const DEMOCM=[['hodan','Awesome! 🔥'],['cabdi','Haha I\'m dying 😂'],['sagal','Keep it up 👏']];
function cmHTML(id){const list=[...DEMOCM.map(([u,t])=>({u,t,d:1})),...seedCm(id)];
 return list.map((c,i)=>{const u=c.u==='me'?ME():usr(c.u);return `<div class="row" style="padding:10px 0"><div class="av sm d">${ini(u.name)}</div><div class="grow" style="white-space:normal"><b style="font-size:13px">@${esc(u.handle)}</b><div style="font-size:14px">${esc(c.t)}</div></div></div>`}).join('')}
function openComments(id){
 if(S.set.cmt==='off'&&false)return;
 sheet('Comments',`<div id="cml">${cmHTML(id)}</div>
 <div class="composer" style="border:0;padding:8px 0 0;position:sticky;bottom:0;background:var(--bg)"><input id="cmi" placeholder="Add a comment…" maxlength="200"><button data-a="sendCm" data-id="${id}">${ic('send')}</button></div>`)}

/* ---------- Discover ---------- */
let dq='',dt='all';
function renderDiscover(){
 const el=$('#tab-discover');
 el.innerHTML=`<div class="search">${ic('search')}<input id="dq" placeholder="Search people, videos, channels, #hashtag" value="${esc(dq)}"></div>
 <div class="chips">${[['all','All'],['users','People'],['videos','Videos'],['chan','Channels'],['tags','Hashtag'],['live','Live'],['snd','Sounds']].map(([k,l])=>`<button class="chip ${dt===k?'on':''}" data-a="dtab" data-v="${k}">${l}</button>`).join('')}</div><div id="dres"></div>`;
 dres()}
const match=s=>!dq||s.toLowerCase().includes(dq.toLowerCase().replace(/^[@#]/,''));
function userRow(u){const fo=S.following[u.id];return `<div class="row click" data-a="user" data-id="${u.id}"><div class="av d">${ini(u.name)}</div><div class="grow"><span class="nm">${esc(u.name)}</span><small>@${esc(u.handle)} · ${fmt(u.f)} followers</small></div><button class="btn s ${fo?'o':''}" data-a="follow" data-id="${u.id}">${fo?'Following':'Follow'}</button></div>`}
function chanRow(c){const s=S.subs[c.id];return `<div class="row click" data-a="chan" data-id="${c.id}"><div class="av" style="border-radius:14px">${ini(c.name)}</div><div class="grow"><span class="nm">${esc(c.name)}</span><small>@${esc(c.handle)} · ${fmt(c.subs+(s?1:0))} subscribers</small></div><button class="btn s ${s?'o':''}" data-a="sub" data-id="${c.id}">${s?'Subscribed':'Subscribe'}</button></div>`}
function grid(ps){return ps.length?`<div class="grid">${ps.map(p=>`<div class="tile" data-a="openPost" data-id="${p.id}">${media(p)}<span class="cnt">${ic('play','fill')} ${fmt(p.likes||0)}</span></div>`).join('')}</div>`:`<div class="empty">Nothing found</div>`}
function dres(){
 const box=$('#dres');if(!box)return;let h='';
 const us=[...S.me?[]:[],...USERS].filter(u=>match(u.name)||match(u.handle));
 const ps=allPosts().filter(p=>match(p.cap)||match(usr(p.uid).handle));
 const cs=[...S.channels,...CHANNELS].filter(c=>match(c.name)||match(c.handle));
 const tg=TAGS.filter(match);
 const lv=LIVES.filter(l=>match(l.t)||match(usr(l.u).name));
 const sn=[...new Set(allPosts().map(p=>p.snd))].filter(Boolean).filter(match);
 const tagRow=t=>`<div class="row click" data-a="tag" data-v="${t}"><div class="av d" style="border-radius:12px">#</div><div class="grow"><span class="nm">#${t}</span><small>${fmt(allPosts().filter(p=>p.cap.includes('#'+t)).length*4210+777)} videos</small></div>${ic('chev')}</div>`;
 const liveRow=l=>`<div class="row click" data-a="openLive" data-id="${l.u}"><div class="av d">${ini(usr(l.u).name)}</div><div class="grow"><span class="nm">${esc(l.t)}</span><small>@${esc(usr(l.u).handle)} · ${fmt(l.v)} watching</small></div><span class="livebadge">LIVE</span></div>`;
 const sndRow=s=>`<div class="row"><div class="av d" style="border-radius:12px">${ic('music')}</div><div class="grow"><span class="nm">${esc(s)}</span><small>Codka</small></div><button class="btn s o" data-a="toast" data-v="Sound saved">Save</button></div>`;
 const sec=(t,x)=>x?`<div class="sec">${t}</div>${x}`:'';
 if(dt==='all'){
  if(!dq)h=sec('Trending hashtags',tg.slice(0,5).map(tagRow).join(''))+sec('Suggested channels',CHANNELS.map(chanRow).join(''))+sec('Popular videos',grid(allPosts().slice(0,9)));
  else h=sec('People',us.slice(0,3).map(userRow).join(''))+sec('Channels',cs.slice(0,3).map(chanRow).join(''))+sec('Hashtag',tg.slice(0,3).map(tagRow).join(''))+sec('Videos',grid(ps));
  if(dq&&!h)h='<div class="empty">Nothing found</div>'}
 else if(dt==='users')h=us.map(userRow).join('')||'<div class="empty">Nothing found</div>';
 else if(dt==='videos')h=grid(ps);
 else if(dt==='chan')h=`<div style="padding:4px 16px"><button class="btn o w" data-a="newChan">${ic('plus')} Create new channel</button></div>`+cs.map(chanRow).join('');
 else if(dt==='tags')h=tg.map(tagRow).join('')||'<div class="empty">Nothing found</div>';
 else if(dt==='live')h=lv.map(liveRow).join('')||'<div class="empty">Nobody is live</div>';
 else if(dt==='snd')h=sn.map(sndRow).join('')||'<div class="empty">Nothing found</div>';
 box.innerHTML=h}

/* ---------- Inbox ---------- */
let ibt='msg';
function renderInbox(){
 const el=$('#tab-inbox');
 const convs=USERS.slice(0,5).map(u=>{const c=S.chats[u.id]||[];return{u,last:c.length?c[c.length-1].t:'Hey! How are you?'}});
 const notes=[['hodan','liked your video','🤍'],['cabdi','started following you',''],['sagal','commented: "Great!"',''],['warsame','mentioned you in a video',''],['ladan','liked 3 videos',''],['yaasiin','subscribed to your channel','']];
 el.innerHTML=`<div class="bar" style="justify-content:center"><h2>Inbox</h2></div><div class="ptabs"><button class="${ibt==='msg'?'on':''}" data-a="ibt" data-v="msg">Messages</button><button class="${ibt==='not'?'on':''}" data-a="ibt" data-v="not">Notifications</button></div>`+
 (ibt==='msg'?convs.map(({u,last})=>`<div class="row click" data-a="chat" data-id="${u.id}"><div class="av d">${ini(u.name)}</div><div class="grow"><span class="nm">${esc(u.name)}</span><small>${esc(last)}</small></div></div>`).join(''):
 notes.map(([u,t])=>`<div class="row"><div class="av d">${ini(usr(u).name)}</div><div class="grow" style="white-space:normal"><b>${esc(usr(u).name)}</b> <span class="mut">${t}</span></div></div>`).join(''))}
function openChat(id){const u=usr(id);S.chats[id]=S.chats[id]||[];
 const draw=d=>{$('.msgs',d).innerHTML=(S.chats[id].length?S.chats[id]:[{t:'Hey! How are you?',me:0}]).map(m=>`<div class="msg ${m.me?'me':''}">${esc(m.t)}</div>`).join('');$('.msgs',d).scrollTop=1e9};
 push(bar(esc(u.name))+`<div class="msgs"></div><form class="composer"><input placeholder="Write a message…" autocomplete="off"><button>${ic('send')}</button></form>`,d=>{draw(d);
  $('form',d).onsubmit=e=>{e.preventDefault();const i=$('input',d),t=i.value.trim();if(!t)return;S.chats[id].push({t,me:1});i.value='';save();draw(d);
   setTimeout(()=>{if(!d.isConnected)return;S.chats[id].push({t:REPLIES[Math.random()*REPLIES.length|0],me:0});save();draw(d)},1100)}})}

/* ---------- Profile ---------- */
let pt='v';
function renderProfile(){
 const el=$('#tab-profile'),m=ME(),mine=S.posts;
 const ps=pt==='v'?mine:pt==='l'?allPosts().filter(p=>S.liked[p.id]):allPosts().filter(p=>S.saved[p.id]);
 const myCh=S.channels;
 el.innerHTML=`<div class="bar"><div style="width:40px"></div><h2>@${esc(m.handle)}</h2><div class="r"><button class="ib" data-a="settings">${ic('set')}</button></div></div>
 <div class="prof"><div class="avw" data-a="pickPic"><div class="av lg">${ini(m.name)}</div><i class="avb">📷</i></div><h3 style="margin:10px 0 2px">${esc(m.name)}</h3><div class="mut">${esc(m.bio||'Add a bio')}</div>
 <div class="stats"><div><b>${Object.keys(S.following).length}</b><span>Following</span></div><div><b>${fmt(m.f)}</b><span>Followers</span></div><div><b>${fmt(mine.reduce((a,p)=>a+(p.likes||0)+(S.liked[p.id]?1:0),0))}</b><span>Likes</span></div></div>
 <div style="display:flex;gap:8px;justify-content:center"><button class="btn o" data-a="editProf">Edit</button><button class="btn o" data-a="share" data-id="me">Share</button><button class="btn o" data-a="ads">${ic('ad')}</button></div></div>
 <div class="sec">My channels</div><div class="chips">${myCh.map(c=>`<button class="chip on" data-a="chan" data-id="${c.id}">${esc(c.name)}</button>`).join('')}<button class="chip" data-a="newChan">+ New channel</button></div>
 <div class="ptabs"><button class="${pt==='v'?'on':''}" data-a="pt" data-v="v">${ic('grid')}</button><button class="${pt==='l'?'on':''}" data-a="pt" data-v="l">${ic('heart')}</button><button class="${pt==='s'?'on':''}" data-a="pt" data-v="s">${ic('bm')}</button></div>
 ${ps.length?grid(ps):`<div class="empty">${pt==='v'?'No videos yet.<br><br><button class="btn" data-a="create">Create your first video</button>':'Nothing here'}</div>`}`}

/* ---------- Other users / channels / posts ---------- */
function openUser(id){if(id==='me'){nav('profile');popAll();return}
 const u=usr(id),ps=allPosts().filter(p=>p.uid===id),fo=S.following[id];
 push(bar('@'+esc(u.handle),`<button class="ib" data-a="share" data-id="u">${ic('more')}</button>`)+`<div class="body"><div class="prof"><div class="av lg d" style="margin:auto">${ini(u.name)}</div><h3 style="margin:10px 0 2px">${esc(u.name)} <span class="badge">${ic('check')}</span></h3><div class="mut">${esc(u.bio)}</div>
 <div class="stats"><div><b>${40+id.length*13}</b><span>Following</span></div><div><b>${fmt(u.f+(fo?1:0))}</b><span>Followers</span></div><div><b>${fmt(ps.reduce((a,p)=>a+p.likes,0))}</b><span>Likes</span></div></div>
 <div style="display:flex;gap:8px;justify-content:center"><button class="btn ${fo?'o':''}" data-a="follow" data-id="${id}" data-page="1">${fo?'Following':'Follow'}</button><button class="btn o" data-a="chat" data-id="${id}">Message</button></div></div>
 <div class="ptabs"><button class="on">${ic('grid')}</button></div>${grid(ps)}</div>`)}
function openChan(id){const c=chan(id),own=c.owner==='me',s=S.subs[id],ps=allPosts().filter(p=>p.ch===id);
 push(bar(esc(c.name),own?`<button class="ib" data-a="editChan" data-id="${id}">${ic('edit')}</button>`:'')+`<div class="body"><div class="prof"><div class="av lg" style="margin:auto;border-radius:24px">${ini(c.name)}</div><h3 style="margin:10px 0 2px">${esc(c.name)}</h3><div class="mut">@${esc(c.handle)}</div><p>${esc(c.bio)}</p>
 <div class="stats"><div><b>${fmt(c.subs+(s?1:0))}</b><span>Macaamiil</span></div><div><b>${ps.length}</b><span>Muuqaal</span></div></div>
 ${own?`<button class="btn" data-a="create" data-ch="${id}">${ic('plus')} Upload video</button> <button class="btn o" data-a="delChan" data-id="${id}">${ic('trash')}</button>`:`<button class="btn ${s?'o':''}" data-a="sub" data-id="${id}" data-page="1">${s?'Subscribed':'Subscribe'}</button>`}</div>${grid(ps)}</div>`)}
function openPost(id){
 const p=allPosts().find(x=>x.id===id);if(!p)return;
 push(`<div style="position:absolute;top:6px;left:6px;z-index:5;color:#fff"><button class="ib" data-a="back" style="background:#0008">${ic('back')}</button></div><div id="feed" style="position:relative;inset:auto;flex:1;overflow:hidden">${reel(p)}</div>`,d=>{
  const v=$('video',d);v&&v.play().catch(()=>{});})}
function chanForm(c){const e=!!c;
 push(bar(e?'Edit channel':'New channel')+`<div class="body"><div class="prof"><div class="av lg" style="margin:auto;border-radius:24px">${ini(c?.name||'Channel')}</div></div>
 <label class="field"><span>Channel name</span><input id="cn" maxlength="30" value="${esc(c?.name||'')}"></label>
 <label class="field"><span>Username</span><input id="ch" maxlength="20" value="${esc(c?.handle||'')}"></label>
 <label class="field"><span>Description</span><textarea id="cb" rows="3" maxlength="150">${esc(c?.bio||'')}</textarea></label>
 <label class="field"><span>Category</span><select id="cc"><option>Madadaalo</option><option>Cunto</option><option>Muusig</option><option>Tiknoolajiyad</option><option>Waxbarasho</option><option>Isboorti</option><option>Ganacsi</option></select></label>
 <div style="padding:12px 16px"><button class="btn w" data-a="saveChan" data-id="${c?.id||''}">${e?'Save':'Create channel'}</button></div></div>`)}

/* ---------- Create ---------- */
function createMenu(chId){
 push(bar('Create')+`<div class="body"><div class="bigopt" data-a="record" data-ch="${chId||''}"><div class="ico">${ic('cam')}</div><div><b>Record video</b><small>Use the camera (9:16)</small></div></div>
 <div class="bigopt" data-a="upload" data-ch="${chId||''}"><div class="ico">${ic('up')}</div><div><b>Upload video</b><small>Choose from your device</small></div></div>
 <div class="bigopt" data-a="goLive"><div class="ico">${ic('live')}</div><div><b>Go Live</b><small>Broadcast now</small></div></div>
 <div class="bigopt" data-a="ads"><div class="ico">${ic('ad')}</div><div><b>Create an ad</b><small>Reach more people</small></div></div></div>`)}
function stopStream(d){d._s&&d._s.getTracks().forEach(t=>t.stop())}
async function camPage(ch,live){
 const d=push(bar(live?'Live':'Duub')+`<div class="cam"><video playsinline muted autoplay></video><span class="timer hid"></span><div class="ctl"><button class="ib" data-a="flip" style="color:#fff">${ic('flip')}</button><button class="rec" data-a="${live?'liveStart':'recToggle'}"><i></i></button><div style="width:40px"></div></div></div>`);
 d.addEventListener('close',()=>{stopStream(d);clearInterval(d._t);d._lv&&clearInterval(d._lv)});d._ch=ch;d._face='user';
 const start=async()=>{stopStream(d);try{d._s=await navigator.mediaDevices.getUserMedia({video:{facingMode:d._face,aspectRatio:9/16},audio:true});$('video',d).srcObject=d._s}catch(e){toast('Camera unavailable. Use Upload.');}};
 d._start=start;start()}
function recToggle(d){const b=$('.rec',d);
 if(d._r&&d._r.state==='recording'){d._r.stop();return}
 if(!d._s)return toast('No camera');
 const chunks=[];let mt='';['video/webm;codecs=vp9,opus','video/webm','video/mp4'].some(m=>window.MediaRecorder&&MediaRecorder.isTypeSupported(m)&&(mt=m));
 try{d._r=new MediaRecorder(d._s,mt?{mimeType:mt}:{})}catch(e){return toast('Recording not supported')}
 d._r.ondataavailable=e=>e.data.size&&chunks.push(e.data);
 d._r.onstop=()=>{clearInterval(d._t);b.classList.remove('on');const blob=new Blob(chunks,{type:d._r.mimeType||'video/webm'});popTo(d);compose(blob,d._ch)};
 d._r.start();b.classList.add('on');let s=0;const tm=$('.timer',d);tm.classList.remove('hid');tm.textContent='0:00';
 d._t=setInterval(()=>{s++;tm.textContent=Math.floor(s/60)+':'+String(s%60).padStart(2,'0');if(s>=60)d._r.stop()},1000)}
function popTo(d){d.dispatchEvent(new Event('close'));d.remove()}
function compose(blob,ch){
 const u=URL.createObjectURL(blob);
 push(bar('Post')+`<div class="body"><div style="display:flex;gap:12px;padding:16px"><video src="${u}" controls playsinline style="width:38%;aspect-ratio:9/16;object-fit:cover;border-radius:12px;background:#111"></video><textarea id="pc" rows="6" maxlength="200" placeholder="Write a caption… #hashtag" style="flex:1;background:var(--card);border:1.5px solid var(--line);border-radius:12px;padding:12px;outline:0;resize:none"></textarea></div>
 <label class="field"><span>Channel</span><select id="pch"><option value="">— My profile —</option>${S.channels.map(c=>`<option value="${c.id}" ${c.id===ch?'selected':''}>${esc(c.name)}</option>`).join('')}</select></label>
 <label class="field"><span>Who can view</span><select id="pv"><option>Everyone</option><option>Followers</option><option>Only me</option></select></label>
 <div style="padding:12px 16px"><button class="btn w" data-a="publish">Post</button></div></div>`,d=>{d._blob=blob;d._url=u})}
async function publish(d){
 const id='m'+Date.now(),cap=$('#pc',d).value.trim()||'New video';
 await idb.put(id,d._blob);vurl[id]=d._url;
 S.posts.unshift({id,uid:'me',ch:$('#pch',d).value||'',cap,likes:0,cm:0,sh:0,snd:'Original sound · '+S.me.name,bg:0,g:'C',vid:1});
 save();popAll();nav('home');toast('Video posted ✓')}

/* ---------- Live ---------- */
function openLive(id){
 const l=LIVES.find(x=>x.u===id)||LIVES[0],u=usr(l.u),names=['Cali','Faadumo','Maxamed','Hodan','Cumar','Sahra','Khaalid'],msgs=['Great 🔥','Hello!','Love it','Play it again','👏👏','Where are you from?'];
 push(`<div class="cam" style="flex:1"><div class="bgart b${l.v%6}" style="position:absolute;inset:0"><div class="glyph">${ini(u.name)}</div></div><div class="scrim" style="position:absolute;inset:0;background:linear-gradient(#0008,transparent 25%,transparent 50%,#000c)"></div>
 <div style="position:absolute;top:10px;left:10px;right:10px;display:flex;align-items:center;gap:8px"><div class="av sm d">${ini(u.name)}</div><div class="grow" style="flex:1"><b>@${esc(u.handle)}</b><div style="font-size:12px"><span class="livebadge">LIVE</span> ${fmt(l.v)} ${ic('eye').replace('class="ic "','class="ic" style="width:12px;height:12px"')}</div></div><button class="btn s" data-a="toast" data-v="You followed">Follow</button><button class="ib" data-a="back" style="color:#fff">${ic('x')}</button></div>
 <div class="livechat"></div></div><form class="composer"><input placeholder="Say something…"><button>${ic('send')}</button></form>`,d=>{
  const box=$('.livechat',d),add=(n,t)=>{box.insertAdjacentHTML('beforeend',`<div><b>${esc(n)}</b> ${esc(t)}</div>`);while(box.children.length>7)box.firstChild.remove()};
  const iv=setInterval(()=>add(names[Math.random()*names.length|0],msgs[Math.random()*msgs.length|0]),1400);d.addEventListener('close',()=>clearInterval(iv));
  $('form',d).onsubmit=e=>{e.preventDefault();const i=$('input',d);if(i.value.trim())add(S.me.name,i.value.trim());i.value=''}})}
function goLive(d){
 const b=$('.rec',d);if(!d._s)return toast('No camera');
 if(d._on){popTo(d);toast('Live ended');return}
 d._on=1;b.classList.add('on');let v=0;const tm=$('.timer',d);tm.classList.remove('hid');
 d._lv=setInterval(()=>{v+=Math.random()*5|0;tm.innerHTML=`<span class="livebadge">LIVE</span> ${v} watching`},1200)}

/* ---------- Ads manager ---------- */
function adsPage(){
 const pg=push(bar('Ads')+`<div class="body" id="adbody"></div>`,d=>drawAds(d))}
function drawAds(d){
 const mine=S.ads,imp=mine.reduce((a,x)=>a+(x.imp||0),0),clk=mine.reduce((a,x)=>a+(x.clk||0),0);
 $('#adbody',d).innerHTML=`<div class="kpi"><div><b>${imp}</b><span>Views</span></div><div><b>${clk}</b><span>Clicks</span></div><div><b>${imp?(clk/imp*100).toFixed(1):0}%</b><span>CTR</span></div></div>
 <div class="sec">New ad</div>
 <label class="field"><span>Business name</span><input id="ab" maxlength="30" value="${esc(S.me.name)}"></label>
 <label class="field"><span>Title</span><input id="at" maxlength="50" placeholder="Tusaale: Qiimo dhimis 20%"></label>
 <label class="field"><span>Text</span><textarea id="ax" rows="2" maxlength="120" placeholder="Sharax adeegga/alaabta"></textarea></label>
 <label class="field"><span>Button (CTA)</span><select id="ac"><option>Learn more</option><option>Buy now</option><option>Visit store</option><option>Contact us</option><option>Download</option></select></label>
 <label class="field"><span>Link (optional)</span><input id="al" placeholder="https://…"></label>
 <label class="field"><span>Daily budget ($)</span><input id="am" type="number" value="5" min="1"></label>
 <div style="padding:8px 16px"><button class="btn w" data-a="addAd">Start ad</button></div>
 <div class="sec">My ads</div>${mine.length?mine.map(a=>`<div class="card"><b>${esc(a.title)}</b><div class="mut" style="font-size:13px;margin:4px 0">${esc(a.text)}</div><small class="mut">${a.imp||0} muuqasho · ${a.clk||0} riix · $${a.budget}/day</small>
  <div style="display:flex;gap:8px;margin-top:10px"><button class="btn s ${a.active?'o':''}" data-a="toggleAd" data-id="${a.id}">${a.active?'Pause':'Resume'}</button><button class="btn s o" data-a="delAd" data-id="${a.id}">${ic('trash')}</button></div></div>`).join(''):'<div class="empty">No ads yet</div>'}`}

/* ---------- Settings ---------- */
const tog=(k,l,s)=>`<div class="row click" data-a="tog" data-k="${k}"><div class="grow"><span class="nm">${l}</span>${s?`<small>${s}</small>`:''}</div><div class="tog ${S.set[k]?'on':''}"></div></div>`;
const nv=(a,l,s='',v='')=>`<div class="row click" data-a="${a}" data-v="${v}"><div class="grow"><span class="nm">${l}</span>${s?`<small>${s}</small>`:''}</div>${ic('chev')}</div>`;
function settings(){push(bar('Settings')+`<div class="body" id="setbody"></div>`,d=>drawSet(d))}
function drawSet(d){
 const b=(d||$('.page:last-child')).querySelector('#setbody');if(!b)return;
 b.innerHTML=`<div class="sec">Akoonka</div>${nv('editProf','Edit profile-ka',ME().name+' · @'+ME().handle)}${nv('newChan','Create channel','Channel-kaaga u gaar ah')}${tog('priv','Akoon gaar ah','Kaliya kuwa aad oggolaato ayaa ku arki kara')}
 <div class="sec">Muuqaalka</div><div class="row click" data-a="theme"><div class="grow"><span class="nm">Mawduuca (Theme)</span><small>${S.set.theme==='dark'?'Madow (Dark)':'Cadaan (Light)'}</small></div><div class="tog ${S.set.theme==='light'?'on':''}"></div></div>
 <div class="sec">Daawashada</div>${tog('autoplay','Si toos ah u ciyaar','Muuqaalada ayaa is-bilaabma')}${tog('sound','Cod markaad gelayso')}${tog('saver','Badbaadiyaha xogta','Tayada hoose, xog yar')}
 <div class="sec">Notifications & Asturnaanta</div>${tog('notif','Notifications push')}<div class="row click" data-a="cmtp"><div class="grow"><span class="nm">Kuwa faallo ku dari kara</span><small>${{all:'Everyone',fr:'Saaxiibbo',off:'Cidna'}[S.set.cmt]}</small></div>${ic('chev')}</div>
 <div class="sec">Ads</div>${nv('ads','Maamulka xayeysiisyada','Samee, hakad ama tirtir')}${tog('pers','Xayeysiis shaqsi ahaan loo habeeyay','Ku saleysan xiisahaaga')}${nv('resetAds','Soo celi xayeysiisyada la qariyay')}
 <div class="sec">Taageero</div>${nv('about','About Caydiid','Nooca 1.0')}${nv('clear','Nadiifi kaydka (cache)')}${nv('logout','Ka bax (Reset)','Wuxuu tirtiraa xogta gudaha')}`}

/* ---------- Navigation ---------- */
let cur='home';
function drawNav(){const t=[['home','home','Home'],['discover','search','Search'],['create','plus',''],['inbox','msg','Inbox'],['profile','user','Profile']];
 $('#nav').innerHTML=t.map(([k,i,l])=>k==='create'?`<button class="plus" data-a="create"><span>${ic('plus')}</span></button>`:`<button class="${cur===k?'on':''}" data-a="nav" data-v="${k}">${ic(i)}<span>${l}</span>${k==='inbox'&&cur!=='inbox'?'<i class="dot">3</i>':''}</button>`).join('')}
function nav(k){popAll();const was=cur;cur=k;$$('.tab').forEach(t=>t.classList.toggle('on',t.id==='tab-'+k));drawNav();
 if(k==='home'){if(was!=='home'||!$('#feed'))renderHome();else $('#feed')&&$$('.reel video',$('#feed')).length}else{$$('#feed video').forEach(v=>v.pause());}
 if(k==='discover')renderDiscover();if(k==='inbox')renderInbox();if(k==='profile')renderProfile()}

/* ---------- Actions ---------- */
let lastTap=0;
const A={
 start(){const n=$('#wn').value.trim(),h=$('#wh').value.trim().toLowerCase().replace(/[^a-z0-9._]/g,'');if(!n)return toast('Enter your name');
  S.me={name:n,handle:h||n.toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,15)||'user',bio:'',f:0};save();$('#welcome').classList.add('hid');renderHome()},
 back:pop,closeSheet,
 nav:el=>nav(el.dataset.v),
 ftab:el=>{feedTab=el.dataset.v;renderHome()},
 goSearch:()=>nav('discover'),
 live:()=>{dt='live';nav('discover')},
 tap(el,e){const t=e.target;if(t.closest('button,[data-a]:not(.frame)')&&t.closest('[data-a]')!==el)return;
  const now=Date.now();if(now-lastTap<320){const r=el.closest('.reel');if(r&&r.dataset.id){if(!S.liked[r.dataset.id])toggleLike(r.dataset.id);const f=$(`.reel[data-id="${r.dataset.id}"] .frame`);burst(f,e.clientX,e.clientY)}lastTap=0;return}
  lastTap=now;setTimeout(()=>{if(lastTap===now&&Date.now()-now>=300){const v=$('video',el);if(v){v.paused?v.play():v.pause()}}},330)},
 like:el=>toggleLike(el.dataset.id),
 save:el=>{const id=el.dataset.id;S.saved[id]=!S.saved[id];if(!S.saved[id])delete S.saved[id];save();refreshReel(id);toast(S.saved[id]?'Saved':'Removed from saved')},
 follow:(el)=>{const id=el.dataset.id;S.following[id]=!S.following[id];if(!S.following[id])delete S.following[id];save();toast(S.following[id]?'You followed':'Unfollowed');
  if(el.dataset.page){el.textContent=S.following[id]?'Following':'Follow';el.classList.toggle('o',!!S.following[id])}else if(cur==='home')$$('.reel').forEach(r=>{const p=allPosts().find(x=>x.id===r.dataset.id);p&&p.uid===id&&refreshReel(p.id)});else if(cur==='discover')dres()},
 user:el=>openUser(el.dataset.id),
 comments:el=>openComments(el.dataset.id),
 sendCm(el){const i=$('#cmi'),t=i.value.trim();if(!t)return;const id=el.dataset.id;(S.comments[id]=S.comments[id]||[]).push({u:'me',t});save();$('#cml').innerHTML=cmHTML(id);i.value='';refreshReelCount(id)},
 share(el){const id=el.dataset.id,url=location.href.split('#')[0]+'#'+id;
  sheet('Share',`<div class="row click" data-a="copy" data-v="${esc(url)}"><div class="av d">${ic('share')}</div><div class="grow"><span class="nm">Copy link</span></div></div><div class="row click" data-a="nativeShare" data-v="${esc(url)}"><div class="av d">${ic('send')}</div><div class="grow"><span class="nm">Send to another app</span></div></div><div class="row click" data-a="toast" data-v="Reported"><div class="av d">${ic('flip')}</div><div class="grow"><span class="nm">Repost</span></div></div><div class="row click" data-a="toast" data-v="Waad ku mahadsantahay warbixinta"><div class="av d">${ic('x')}</div><div class="grow"><span class="nm">Not interested</span></div></div>`)},
 copy(el){navigator.clipboard?.writeText(el.dataset.v).catch(()=>{});closeSheet();toast('Link copied')},
 nativeShare(el){closeSheet();navigator.share?navigator.share({title:'Caydiid',url:el.dataset.v}).catch(()=>{}):toast('Not supported in this browser')},
 toast:el=>{closeSheet();toast(el.dataset.v)},
 dtab:el=>{dt=el.dataset.v;$$('.chip').forEach(c=>c.classList.toggle('on',c.dataset.v===dt));dres()},
 tag:el=>{dq='#'+el.dataset.v;dt='videos';renderDiscover()},
 openPost:el=>openPost(el.dataset.id),
 openLive:el=>openLive(el.dataset.id),
 chan:el=>openChan(el.dataset.id),
 sub(el){const id=el.dataset.id;S.subs[id]=!S.subs[id];if(!S.subs[id])delete S.subs[id];save();toast(S.subs[id]?'Subscribed':'Unfollowed');
  if(el.dataset.page){el.textContent=S.subs[id]?'Subscribed':'Subscribe';el.classList.toggle('o',!!S.subs[id])}else dres()},
 newChan:()=>chanForm(),
 editChan:el=>chanForm(chan(el.dataset.id)),
 saveChan(el){const n=$('#cn').value.trim();if(!n)return toast('Enter channel name');const id=el.dataset.id;
  const o={name:n,handle:$('#ch').value.trim().toLowerCase().replace(/[^a-z0-9._]/g,'')||n.toLowerCase().replace(/\W/g,''),bio:$('#cb').value.trim()||'New channel'};
  if(id){Object.assign(S.channels.find(c=>c.id===id),o)}else S.channels.push({id:'ch'+Date.now(),owner:'me',subs:0,...o});
  save();popAll();nav('profile');toast('Channel saved ✓')},
 delChan(el){if(!confirm('Delete this channel?'))return;S.channels=S.channels.filter(c=>c.id!==el.dataset.id);save();popAll();nav('profile')},
 create:el=>{if(el.dataset.ch){popAll()}createMenu(el.dataset.ch)},
 record:el=>camPage(el.dataset.ch),
 goLive:()=>camPage('',true),
 liveStart:el=>goLive(el.closest('.page')),
 recToggle:el=>recToggle(el.closest('.page')),
 flip:el=>{const d=el.closest('.page');d._face=d._face==='user'?'environment':'user';d._start()},
 upload(el){const i=document.createElement('input');i.type='file';i.accept='video/*';i.onchange=()=>{const f=i.files[0];if(f){compose(f,el.dataset.ch)}};i.click()},
 publish:el=>publish(el.closest('.page')),
 ads:()=>adsPage(),
 addAd(){const t=$('#at').value.trim();if(!t)return toast('Enter ad title');
  S.ads.unshift({id:'u'+Date.now(),brand:$('#ab').value.trim()||S.me.name,title:t,text:$('#ax').value.trim()||'New ad',cta:$('#ac').value,link:$('#al').value.trim(),budget:+$('#am').value||5,active:1,imp:0,clk:0,bg:Math.random()*6|0,g:ini($('#ab').value||S.me.name)});
  save();drawAds($('.page:last-child'));toast('Ad is running ✓')},
 toggleAd(el){const a=S.ads.find(x=>x.id===el.dataset.id);a.active=a.active?0:1;save();drawAds($('.page:last-child'))},
 delAd(el){S.ads=S.ads.filter(x=>x.id!==el.dataset.id);save();drawAds($('.page:last-child'))},
 adClick(el){const a=adsList().concat(S.ads).find(x=>x.id===el.dataset.id);if(!a)return;const m=S.ads.find(x=>x.id===a.id);if(m){m.clk=(m.clk||0)+1;save()}
  if(/^https?:\/\//.test(a.link))window.open(a.link,'_blank','noopener');else toast(a.cta+' — '+a.brand)},
 adMenu(el){const id=el.dataset.id;sheet('Xayeysiis',`<div class="row click" data-a="hideAd" data-id="${id}"><div class="av d">${ic('x')}</div><div class="grow"><span class="nm">Hide this ad</span></div></div><div class="row click" data-a="ads"><div class="av d">${ic('ad')}</div><div class="grow"><span class="nm">Samee xayeysiis</span></div></div>`)},
 hideAd(el){S.hiddenAds[el.dataset.id]=1;save();closeSheet();renderHome();toast('This ad will be hidden')},
 resetAds(){S.hiddenAds={};save();toast('Restored')},
 ibt:el=>{ibt=el.dataset.v;renderInbox()},
 chat(el){if(el.closest('.page')&&el.dataset.id)popAll();openChat(el.dataset.id)},
 pt:el=>{pt=el.dataset.v;renderProfile()},
 settings,
 editProf(){push(bar('Edit profile')+`<div class="body"><div class="prof"><div class="avw" data-a="pickPic"><div class="av lg">${ini(S.me.name)}</div><i class="avb">📷</i></div><div style="display:flex;gap:8px;justify-content:center;margin-top:10px"><button class="btn s o" data-a="pickPic">Change photo</button>${S.me.pic?'<button class="btn s o" data-a="rmPic">Remove</button>':''}</div></div>
  <label class="field"><span>Magac</span><input id="en" maxlength="30" value="${esc(S.me.name)}"></label><label class="field"><span>Username</span><input id="eh" maxlength="20" value="${esc(S.me.handle)}"></label><label class="field"><span>Bio</span><textarea id="eb" rows="3" maxlength="100">${esc(S.me.bio)}</textarea></label>
  <div style="padding:12px 16px"><button class="btn w" data-a="saveProf">Save</button></div></div>`)},
 saveProf(){const n=$('#en').value.trim();if(!n)return toast('Enter a name');S.me.name=n;S.me.handle=$('#eh').value.trim().toLowerCase().replace(/[^a-z0-9._]/g,'')||S.me.handle;S.me.bio=$('#eb').value.trim();save();pop();renderProfile();drawSet();toast('Saved ✓')},
 tog(el){const k=el.dataset.k;S.set[k]=!S.set[k];save();drawSet()},
 theme(){S.set.theme=S.set.theme==='dark'?'light':'dark';save();applyTheme();drawSet()},
 cmtp(){const o=['all','fr','off'];S.set.cmt=o[(o.indexOf(S.set.cmt)+1)%3];save();drawSet()},
 about:()=>sheet('Caydiid 1.0',`<div style="text-align:center;padding:10px">${logo('',80)}<p>Caydiid — a short-video app.<br>9:16 videos, channels, live, ads and settings.</p></div>`),
 clear:async()=>{if(!confirm('Delete locally saved videos?'))return;for(const p of S.posts)await idb.del(p.id);S.posts=[];save();toast('Cleared')},
 logout(){if(!confirm('Delete all data and restart?'))return;localStorage.removeItem(LSKEY);location.reload()}
};
function refreshReelCount(id){refreshReel(id)}
document.addEventListener('click',e=>{const el=e.target.closest('[data-a]');if(!el)return;const f=A[el.dataset.a];if(f){f(el,e)}});
document.addEventListener('input',e=>{if(e.target.id==='dq'){dq=e.target.value;dres()}});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.id==='cmi')$('[data-a=sendCm]').click()});

/* ---------- Start ---------- */
if(S.me&&!S.me.verified){window.__oldMe=S.me;S.me=null} /* sign-up (e-mail code) is required before using the app */
(async function init(){
 applyTheme();await idb.open();
 for(const p of S.posts){if(p.vid){const b=await idb.get(p.id);if(b)vurl[p.id]=URL.createObjectURL(b)}}
 drawNav();
 if(!S.me)welcome();else renderHome();
 if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
})();
