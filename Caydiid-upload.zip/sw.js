const C='caydiid-v15',F=['./','index.html','styles.css','app.js','features.js','features2.js','features3.js','features4.js','features5.js','features6.js','logo.png','manifest.json'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(F))));
self.addEventListener('fetch',e=>e.respondWith(fetch(e.request).catch(()=>caches.match(e.request))));
