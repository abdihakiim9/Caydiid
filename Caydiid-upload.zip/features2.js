'use strict';
/* ===== Caydiid v1.2: WhatsApp-style Chats, contacts by number, themes ===== */
S.contacts=S.contacts||[];
const tm=ts=>{if(!ts)return'';const d=new Date(ts);return d.getHours()+':'+String(d.getMinutes()).padStart(2,'0')};
const cinfo=id=>{const c=S.contacts.find(x=>x.id===id);if(c)return{name:c.name,sub:c.phone,c:1};const u=usr(id);return{name:u.name,sub:'@'+u.handle}};
const mbody=x=>x.v?vn(x.v,x.d):x.e?bigE(x.e):esc(x.t);
function chatPage(id,wa){const ci=cinfo(id);S.chats[id]=S.chats[id]||[];
 const draw=d=>{const m=$('.msgs',d);m.innerHTML=S.chats[id].map(x=>`<div class="msg ${x.me?'me':''}">${mbody(x)}<small class="ts">${tm(x.ts)}${x.me&&wa?' ✓✓':''}</small></div>`).join('')||`<div class="empty">Say hi 👋${ci.c?'<br><br><button class="btn s o" data-a="invite">Invite to Caydiid</button>':''}</div>`;hydrate(m);m.scrollTop=1e9};
 push(bar(`${esc(ci.name)}<br><small class="mut" style="font-weight:400;font-size:11px">${esc(ci.sub)}</small>`,wa?`<button class="ib" data-a="call" data-v="voice">📞</button><button class="ib" data-a="call" data-v="video">🎥</button>`:'')+`<div class="msgs"></div><form class="composer cmc">${wa?'<button type="button" class="ib" data-a="emoMsg">😊</button>':''}<input placeholder="Message" autocomplete="off">${wa?'<button type="button" class="ib mic" data-a="micMsg">🎙️</button>':''}<button class="ib snd ${wa?'hid':''}">${ic('send')}</button></form>`,d=>{
  d._id=id;d._draw=()=>draw(d);draw(d);const i=$('input',d);
  if(wa)i.oninput=()=>{$('.mic',d).classList.toggle('hid',!!i.value);$('.snd',d).classList.toggle('hid',!i.value)};
  $('form',d).onsubmit=e=>{e.preventDefault();const t=i.value.trim();if(!t)return;S.chats[id].push({t,me:1,ts:Date.now()});i.value='';save();draw(d);if(wa)i.oninput()}})}
openChat=id=>chatPage(id,false); /* Inbox: text only, no voice */
Object.assign(A,{
 micMsg(el){const d=el.closest('.page');mic(el,async(b,dur)=>{const k=await vsave(b);S.chats[d._id].push({v:k,d:dur,me:1,ts:Date.now()});save();d._draw()})},
 emoMsg(el){const d=el.closest('.page');emoToggle(el.closest('form'),e=>{S.chats[d._id].push({e,me:1,ts:Date.now()});save();d._draw()})},
 waChat:el=>chatPage(el.dataset.id,true),
 invite(){const t='Join me on Caydiid!';navigator.share?navigator.share({title:'Caydiid',text:t,url:location.href}).catch(()=>{}):(navigator.clipboard?.writeText(t+' '+location.href),toast('Invite copied'))},
 newContact(){push(bar('New contact')+`<div class="body"><div class="prof"><div class="av lg" style="margin:auto">+</div></div><label class="field"><span>Name</span><input id="kn" maxlength="30" placeholder="Full name"></label><label class="field"><span>Phone number</span><input id="kp" type="tel" maxlength="20" placeholder="+252 61 000 0000"></label><div style="padding:12px 16px"><button class="btn w" data-a="saveContact">Save & chat</button></div>${S.contacts.length?'<div class="sec">Saved contacts</div>'+S.contacts.map(c=>`<div class="row click" data-a="waChat" data-id="${c.id}"><div class="av d">${ini(c.name)}</div><div class="grow"><span class="nm">${esc(c.name)}</span><small>${esc(c.phone)}</small></div></div>`).join(''):''}</div>`)},
 saveContact(){const n=$('#kn').value.trim(),p=$('#kp').value.trim(),dg=p.replace(/\D/g,'');if(!n)return toast('Enter a name');if(dg.length<6)return toast('Enter a valid phone number');
  const id='k'+dg;if(!S.contacts.find(c=>c.id===id))S.contacts.push({id,name:n,phone:p});S.chats[id]=S.chats[id]||[];save();popAll();nav('chats');chatPage(id,true)},
 theme(){const o=['dark','light','auto'];S.set.theme=o[(o.indexOf(S.set.theme)+1)%3];save();applyTheme();drawSet()}});
function renderChats(){const el=$('#tab-chats');if(!el)return;
 el.innerHTML=`<div class="bar"><div style="width:40px"></div><h2>Chats</h2><div class="r"><button class="ib" data-a="newContact">${ic('plus')}</button></div></div><div class="search">${ic('search')}<input id="cq" placeholder="Search chats or numbers"></div><div id="cl"></div>`;chatList()}
function chatList(){const b=$('#cl');if(!b)return;const q=($('#cq').value||'').toLowerCase().replace(/^\+/,'');
 const ids=[...new Set([...S.contacts.map(c=>c.id),...Object.keys(S.chats).filter(k=>S.chats[k].length)])];
 const lt=id=>{const c=S.chats[id]||[];return c.length?c[c.length-1]:null};
 const rows=ids.map(id=>({id,ci:cinfo(id),l:lt(id)})).filter(r=>r.ci.name.toLowerCase().includes(q)||r.ci.sub.replace(/\D/g,'').includes(q.replace(/\D/g,'')||'§')).sort((a,b)=>(b.l?.ts||0)-(a.l?.ts||0));
 b.innerHTML=`<div class="row click" data-a="newContact"><div class="av">${ic('plus')}</div><div class="grow"><span class="nm">New contact</span><small>Add a phone number</small></div></div>`+rows.map(({id,ci,l})=>`<div class="row click" data-a="waChat" data-id="${id}"><div class="av d">${ini(ci.name)}</div><div class="grow"><span class="nm">${esc(ci.name)}</span><small>${l?(l.v?'🎙️ Voice message':l.e||esc(l.t)):esc(ci.sub)}</small></div><small class="mut">${l?tm(l.ts):''}</small></div>`).join('')}
document.addEventListener('input',e=>{if(e.target.id==='cq')chatList()});
const sc=document.createElement('section');sc.className='tab';sc.id='tab-chats';$('#screens').append(sc);
drawNav=function(){const t=[['home','home','Home'],['chats','users','Friends'],['create','plus',''],['inbox','msg','Inbox'],['profile','user','Profile']];
 $('#nav').innerHTML=t.map(([k,i,l])=>k==='create'?`<button class="plus" data-a="create"><span>${ic('plus')}</span></button>`:`<button class="${cur===k?'on':''}" data-a="nav" data-v="${k}">${ic(i)}<span>${l}</span>${k==='inbox'&&cur!=='inbox'?'<i class="dot">3</i>':''}</button>`).join('')};
const _nav=nav;nav=function(k){_nav(k);if(k==='chats')renderChats()};
applyTheme=function(){const t=S.set.theme==='auto'?(matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'):S.set.theme;document.documentElement.dataset.theme=t;$('meta[name=theme-color]').content=t==='dark'?'#000000':'#ffffff'};
applyTheme();drawNav();

/* ---- TikTok-style home ---- */
const LIVEI='<svg viewBox="0 0 32 32" width="30" height="30"><path d="M10 4l6 4 6-4" stroke="#fff" fill="none" stroke-width="2" stroke-linecap="round"/><rect x="3" y="8" width="26" height="20" rx="4" fill="none" stroke="#fff" stroke-width="2.5"/><text x="16" y="22.5" text-anchor="middle" font-size="9" font-weight="900" fill="#fff" font-family="Arial,sans-serif">LIVE</text></svg>';
const _bf=buildFeed;buildFeed=function(){const t=feedTab;feedTab='fy';let o=_bf();feedTab=t;if(t==='fo'){feedTab='fo';o=_bf();feedTab=t}if(t==='cm')o=o.filter(p=>p.ad||p.ch);if(t==='nb')o=o.filter((p,i)=>i%2===0);return o};
const _rh=renderHome;renderHome=function(k){_rh(k);const h=$('.homebar');if(h)h.innerHTML=`<button class="ib" data-a="live">${LIVEI}</button><div class="tabs">${[['cm','Community'],['nb','Nearby'],['fo','Following'],['fy','For You']].map(([v,l])=>`<button data-a="ftab" data-v="${v}" class="${feedTab===v?'on':''}">${l}</button>`).join('')}</div><button class="ib" data-a="goSearch">${ic('search')}</button>`};
const _reel=reel;reel=function(p){const h=_reel(p);return p.ad?h:h.replace(/<span>(Save|Saved)<\/span>/,`<span>${fmt(Math.round((p.likes||0)/50)+(S.saved[p.id]?1:0))}</span>`)};
if(cur==='home'&&S.me)renderHome();
