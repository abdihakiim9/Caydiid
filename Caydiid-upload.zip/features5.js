'use strict';
/* ===== Caydiid v1.5: go-live confirmation, face beauty, face reshaping (MediaPipe + WebGL), laugh filters ===== */
const MPV='https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14';
function loadFace(){if(loadFace.p)return loadFace.p;return loadFace.p=(async()=>{try{const m=await import(MPV+'/vision_bundle.mjs'),fs=await m.FilesetResolver.forVisionTasks(MPV+'/wasm');
 const mk=d=>m.FaceLandmarker.createFromOptions(fs,{baseOptions:{modelAssetPath:'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task',delegate:d},runningMode:'VIDEO',numFaces:1});
 try{return await mk('GPU')}catch(e){return await mk('CPU')}}catch(e){return null}})()}
const VS='attribute vec2 p;varying vec2 uv;void main(){uv=vec2((p.x+1.)/2.,(1.-p.y)/2.);gl_Position=vec4(p,0.,1.);}';
const FS=`precision mediump float;varying vec2 uv;uniform sampler2D tex;uniform vec2 px;uniform float asp,uSm;uniform vec4 uA[14];uniform vec4 uB[14];
void main(){vec2 p=uv;
 for(int i=0;i<14;i++){vec4 a=uA[i];if(a.z<=0.0)continue;vec2 d=p-a.xy;d.x*=asp;float t=length(d)/a.z;
  if(t<1.0){float f=(1.0-t);f*=f;if(uB[i].x<0.5){p=a.xy+vec2(d.x/asp,d.y)*(1.0-a.w*f);}else{p-=vec2(uB[i].y/asp,uB[i].z)*a.w*f*a.z;}}}
 vec4 c=texture2D(tex,p);
 if(uSm>0.0){vec3 s=vec3(0.0);float w=0.0;for(int i=0;i<8;i++){float g=float(i)*0.785398;vec3 q=texture2D(tex,p+vec2(cos(g),sin(g))*px*3.0).rgb;float k=exp(-dot(q-c.rgb,q-c.rgb)*40.0);s+=q*k;w+=k;}c.rgb=mix(c.rgb,(c.rgb+s)/(1.0+w),uSm);}
 gl_FragColor=vec4(c.rgb,1.0);}`;
function warps(lm,asp,l,t){const F=l.face||{},q=k=>(F[k]||0)/100,P=i=>lm[i],M=(a,b)=>({x:(lm[a].x+lm[b].x)/2,y:(lm[a].y+lm[b].y)/2}),D=(a,b)=>Math.hypot((lm[a].x-lm[b].x)*asp,lm[a].y-lm[b].y);
 const W=[],bu=(c,r,s)=>s&&W.push([c.x,c.y,r,s*.8,0,0,0]),pu=(c,r,s,dx,dy)=>s&&W.push([c.x,c.y,r,s,1,dx,dy]);const fw=D(234,454),mw=D(61,291),f=l.fun;
 bu(P(4),D(98,327)*.9,q('nose'));bu(M(13,14),mw*.62,q('lips'));bu(M(13,14),mw*.3,q('teeth'));bu(M(33,133),D(33,133)*1.1,q('eyes'));bu(M(362,263),D(362,263)*1.1,q('eyes'));bu(M(10,152),D(10,152)*.95,q('head'));
 pu(P(234),fw*.42,q('face')*.8,1,0);pu(P(454),fw*.42,q('face')*.8,-1,0);pu(P(172),fw*.3,q('jaw')*.8,.8,-.6);pu(P(397),fw*.3,q('jaw')*.8,-.8,-.6);
 if(f==='smile'||f==='cartoon'){pu(P(61),mw*.5,.6,-.55,-.8);pu(P(291),mw*.5,.6,.55,-.8)}
 if(f==='cartoon'){bu(M(33,133),D(33,133)*1.2,.7);bu(M(362,263),D(362,263)*1.2,.7)}
 if(f==='laugh'){const o=(Math.sin(t*10)+1)/2;pu(P(61),mw*.5,.5+.3*o,-.55,-.8);pu(P(291),mw*.5,.5+.3*o,.55,-.8);pu(P(152),fw*.5,.55*o,0,1)}
 return W.slice(0,14)}
const ctxF=l=>`${FX[l.fx]||''} brightness(${l.bright}%) contrast(${1+(l.enh||0)*.06}) saturate(${1+(l.enh||0)*.1})`;
function engine(src){
 const v=document.createElement('video');v.srcObject=src;v.muted=true;v.playsInline=true;v.style.cssText='position:fixed;opacity:0;width:2px;height:2px;pointer-events:none';document.body.append(v);v.play().catch(()=>{});
 const gc=document.createElement('canvas'),gl=gc.getContext('webgl',{preserveDrawingBuffer:true}),out=document.createElement('canvas'),x=out.getContext('2d'),loc={};out.width=720;out.height=1200;
 const E={v,out,lm:null,fl:null,n:0,t0:performance.now(),setSrc(s){v.srcObject=s;v.play().catch(()=>{})},stop(){clearInterval(E.t);v.remove();gl&&gl.getExtension('WEBGL_lose_context')&&gl.getExtension('WEBGL_lose_context').loseContext()}};
 if(gl){const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);return o},pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,VS));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(pr);gl.useProgram(pr);
  gl.bindBuffer(gl.ARRAY_BUFFER,gl.createBuffer());gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);const a=gl.getAttribLocation(pr,'p');gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,2,gl.FLOAT,false,0,0);
  ['tex','px','asp','uSm','uA','uB'].forEach(n=>loc[n]=gl.getUniformLocation(pr,n));gl.bindTexture(gl.TEXTURE_2D,gl.createTexture());
  [[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE],[gl.TEXTURE_MIN_FILTER,gl.LINEAR],[gl.TEXTURE_MAG_FILTER,gl.LINEAR]].forEach(([k,z])=>gl.texParameteri(gl.TEXTURE_2D,k,z))}
 loadFace().then(f=>E.fl=f);
 E.t=setInterval(()=>{if(!v.videoWidth||v.readyState<2)return;const l=LS(),t=(performance.now()-E.t0)/1000,vw=v.videoWidth,vh=v.videoHeight,asp=vw/vh;let src=v;
  if(gl){const sc=Math.min(1,960/Math.max(vw,vh)),w=Math.round(vw*sc),h=Math.round(vh*sc);if(gc.width!==w){gc.width=w;gc.height=h;gl.viewport(0,0,w,h)}
   if(E.fl&&E.n++%3===0){try{const r=E.fl.detectForVideo(v,performance.now()),f=r.faceLandmarks&&r.faceLandmarks[0];E.lm=f?(E.lm?f.map((q,i)=>({x:E.lm[i].x+(q.x-E.lm[i].x)*.6,y:E.lm[i].y+(q.y-E.lm[i].y)*.6})):f.map(q=>({x:q.x,y:q.y}))):null}catch(e){}}
   const W=E.lm?warps(E.lm,asp,l,t):[],A=new Float32Array(56),B=new Float32Array(56);W.forEach((k,i)=>{A.set(k.slice(0,4),i*4);B.set([k[4],k[5],k[6],0],i*4)});
   gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,v);gl.uniform1i(loc.tex,0);gl.uniform2f(loc.px,1/w,1/h);gl.uniform1f(loc.asp,asp);gl.uniform1f(loc.uSm,(l.smooth||0)/5*.85);gl.uniform4fv(loc.uA,A);gl.uniform4fv(loc.uB,B);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);src=gc}
  const OW=720,OH=1200;if(out.width!==OW||out.height!==OH){out.width=OW;out.height=OH}const k=Math.max(OW/vw,OH/vh)*(l.fun==='laugh'?1.01:1),w=vw*k,h=vh*k,ox=(OW-w)/2,oy=(OH-h)/2+(l.fun==='laugh'?Math.sin(t*12)*OH*.004:0);
  x.filter=ctxF(l);x.drawImage(src,ox,oy,w,h);x.filter='none';
  if(l.fun==='laugh'&&E.lm){x.font=Math.round(w/10)+'px serif';x.textAlign='center';[145,374].forEach((i,k)=>{const ph=(t*1.4+k*.5)%1;x.globalAlpha=1-ph;x.fillText('😂',ox+E.lm[i].x*w,oy+E.lm[i].y*h+ph*h*.1)});x.globalAlpha=1}
 },33);return E}
/* ---- override setup / live start to use the engine ---- */
async function liveSetup(){if(!pj())return toast('Network library not loaded — check your internet');const l=LS();loadFace().then(f=>{if(!f)toast('Face reshaping unavailable (needs internet)')});
 const d=push(`<div class="lsu"><div class="lsvo hid"><div class="av lg">${ini(S.me.name)}</div><p>Voice chat — audio only</p></div><button class="ib lsx" data-a="lsClose">${ic('x')}</button>
 <div class="tools">${tool('lsFlip',ic('flip'),'Flip')}${tool('lsBeauty','🪄','Beautify')}${tool('lsFace','🙂','Face')}${tool('lsFx','✨','Effects')}${tool('lsSet',ic('set'),'Settings')}${tool('lsFun','😂','Funny')}${tool('shareLive',ic('share'),'Share')}${tool('lsInter',ic('msg'),'Interact')}${tool('ads','🔥','Promote')}${tool('lsMic','🎙️','Mic')}</div>
 <div class="lscard"><div class="lsrow"><div class="av sm">${ini(S.me.name)}</div><input id="lt" placeholder="Add a title" maxlength="60" value="${esc(l.title)}"><button class="lsgoal" data-a="lsGoal">🎯 LIVE goal${l.goal?' '+l.goal:''}</button></div><button class="golive" data-a="lsGo">Go LIVE</button></div>
 <div class="lsmodes"><button data-a="lsMode" data-v="voice" class="${l.mode==='voice'?'on':''}">🎙️ Voice chat</button><button data-a="lsMode" data-v="cam" class="${l.mode==='cam'?'on':''}">📷 Device camera</button></div>
 <div class="lstabs"><button data-a="lsPost">POST</button><b>LIVE</b><button data-a="lsCreate">CREATE</button></div></div>`);
 d.addEventListener('close',()=>{stopStream(d);d._fx&&d._fx.stop()});d._face='user';await lsStart(d)}
async function lsStart(d){stopStream(d);d._fx&&d._fx.stop();d._fx=null;const l=LS();try{d._s=await lstream(d._face,l)}catch(e){toast('Camera/mic permission needed (HTTPS)');return}
 d.querySelectorAll('.fxc').forEach(c=>c.remove());$('.lsvo',d).classList.toggle('hid',l.mode!=='voice');
 if(l.mode!=='voice'){d._fx=engine(d._s);const c=d._fx.out;c.className='fxc self'+(d._face!=='user'?' rear':'');$('.lsu',d).prepend(c)}d._s.getAudioTracks().forEach(t=>t.enabled=!!l.mic)}
function startLive(raw,fx){const l=LS(),id='cdd-live-'+slug(S.me.handle),d=livePage('Live',1),voice=l.mode==='voice';S.ui.pg=['livehost'];save();d._s=raw;d._face=d._face||'user';let out=raw;
 $('.rv',d).classList.add('hid');if(!voice){fx=fx||engine(raw);d._fx=fx;const c=fx.out;c.className='fxc self';d.querySelector('.cam').prepend(c);out=new MediaStream([...c.captureStream(30).getVideoTracks(),...raw.getAudioTracks()])}
 const calls=new Set(),conns=[];let P;const upd=()=>{$('.vc',d).textContent=calls.size+(l.goal?' / '+l.goal:'')};upd();
 d.querySelector('.cam').insertAdjacentHTML('beforeend',`<div class="hud">${l.title?esc(l.title):''}</div>`);
 $('.callbar',d).insertAdjacentHTML('afterbegin',`<button class="btn s o" data-a="lsFlipLive">Flip</button><button class="btn s o" data-a="lsMicLive">Mic</button><button class="btn s o" data-a="lsFx">Effects</button><button class="btn s o" data-a="lsFace">Face</button><button class="btn s o" data-a="lsFun">😂</button>`);
 const host=n=>{P=new Peer(id);
  P.on('error',e=>{if(e.type==='unavailable-id'){P.destroy();if(n<6)setTimeout(()=>d.isConnected&&host(n+1),2500);else{toast('You are already live on another device');d.isConnected&&pop()}}});
  P.on('call',c=>{c.answer(out);calls.add(c);upd();c.on('close',()=>{calls.delete(c);upd()})});
  P.on('connection',c=>{conns.push(c);c.on('open',()=>c.send({sys:'cfg',chat:l.chat,title:l.title}));c.on('data',m=>{if(!l.chat||m.sys)return;chatAdd(d,m);conns.forEach(x=>x!==c&&x.open&&x.send(m))})})};host(0);
 d.addEventListener('close',()=>{P&&P.destroy();stopStream(d);d._v2&&d._v2.getTracks().forEach(t=>t.stop());d._fx&&d._fx.stop()});
 $('form',d).onsubmit=e=>{e.preventDefault();const i=$('input',d),t=i.value.trim();if(!t)return;const m={n:S.me.name,t};chatAdd(d,m);conns.forEach(x=>x.open&&x.send(m));i.value=''}}
/* ---- sheets & actions ---- */
const rng=(id,t,min,max,val)=>`<div class="sec">${t}</div><input type="range" id="${id}" min="${min}" max="${max}" step="1" value="${val}" style="width:100%">`;
const FACE=[['face','Face slim (0 → slimmer)',0],['jaw','Jaw / chin slim',0],['nose','Nose (− smaller, + bigger)',-100],['eyes','Eyes',-100],['lips','Lips',-100],['teeth','Teeth',-100],['head','Head size',-100]];
Object.assign(A,{
 lsBeauty(){const l=LS();sheet('Beautify',rng('bsm','Skin smoothing',0,5,l.smooth)+rng('bbr','Brightness',80,140,l.bright)+rng('ben','Enhance (contrast & color)',0,5,l.enh||0))},
 lsFace(){const l=LS();l.face=l.face||{};sheet('Reshape face',FACE.map(([k,t,mn])=>rng('fc_'+k,t,mn,100,l.face[k]||0)).join('')+'<button class="btn o w" data-a="faceReset" style="margin-top:12px">Reset</button>'+(loadFace.p?'':''))},
 faceReset(){LS().face={};save();A.lsFace()},
 lsFun(){const l=LS();sheet('Funny filters',`<div class="chips">${[['','None'],['smile','😄 Smile'],['laugh','😂 Laugh'],['cartoon','🤪 Cartoon']].map(([k,n])=>`<button class="chip ${(l.fun||'')===k?'on':''}" data-a="lsFunSet" data-v="${k}">${n}</button>`).join('')}</div><p class="mut" style="font-size:12px">Needs face tracking (internet on first use).</p>`)},
 lsFunSet(el){LS().fun=el.dataset.v;save();A.lsFun()},
 async lsFlipLive(el){const d=el.closest('.page');d._face=d._face==='user'?'environment':'user';try{const n=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:d._face}});d._v2&&d._v2.getTracks().forEach(t=>t.stop());d._s.getVideoTracks().forEach(t=>t.stop());d._v2=n;d._fx&&d._fx.setSrc(n);const c=$('.fxc',d);c&&c.classList.toggle('rear',d._face!=='user')}catch(e){toast('Cannot switch camera')}},
 lsGo(el){LS().title=$('#lt',el.closest('.page')).value.trim();save();sheet('Go LIVE?',`<p style="font-size:15px;line-height:1.5;padding:4px 2px">Are you sure you want to go live? Your camera and microphone will be visible to anyone who opens your live link.</p><button class="btn w" data-a="lsGoOk" style="margin-top:8px">Yes, Go LIVE</button><button class="btn o w" data-a="closeSheet" style="margin-top:8px">Not now</button>`)},
 lsGoOk(){closeSheet();const d=pg();if(!d||!d._s)return toast('Camera/mic not ready');const raw=d._s,fx=d._fx;d._s=null;d._fx=null;d.remove();startLive(raw,fx)}});
document.addEventListener('input',e=>{const i=e.target.id||'',l=LS();if(i==='ben'){l.enh=+e.target.value;save()}else if(i.startsWith('fc_')){l.face=l.face||{};l.face[i.slice(3)]=+e.target.value;save()}});
/* ---- pause indicator: big play icon on a paused feed video ---- */
(()=>{const ICON='<svg viewBox="0 0 24 24" width="38" height="38" fill="#fff"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/></svg>';
 const mark=(v,on)=>{const f=v.closest&&v.closest('.reel .frame');if(!f)return;let p=f.querySelector(':scope>.pz');if(!p){if(!on)return;p=document.createElement('div');p.className='pz';p.innerHTML=ICON;f.append(p)}p.classList.toggle('on',on)};
 document.addEventListener('pause',e=>{if(e.target.tagName==='VIDEO'&&!e.target.ended)mark(e.target,true)},true);
 document.addEventListener('play',e=>{if(e.target.tagName==='VIDEO')mark(e.target,false)},true);
 document.addEventListener('playing',e=>{if(e.target.tagName==='VIDEO')mark(e.target,false)},true)})();

/* ---- change profile photo ---- */
(()=>{const refresh=()=>{try{renderProfile()}catch(e){};const pg=document.querySelector('#pages .page:last-child');if(pg&&pg.querySelector('[data-a=saveProf]')){const n=$('#en',pg).value,h=$('#eh',pg).value,b=$('#eb',pg).value;pop();A.editProf();const q=document.querySelector('#pages .page:last-child');$('#en',q).value=n;$('#eh',q).value=h;$('#eb',q).value=b}};
 const shrink=file=>new Promise((ok,no)=>{const u=URL.createObjectURL(file),im=new Image();im.onload=()=>{const S0=320,c=document.createElement('canvas');c.width=c.height=S0;const x=c.getContext('2d'),w=im.naturalWidth,h=im.naturalHeight,m=Math.min(w,h);x.drawImage(im,(w-m)/2,(h-m)/2,m,m,0,0,S0,S0);URL.revokeObjectURL(u);ok(c.toDataURL('image/jpeg',.85))};im.onerror=()=>{URL.revokeObjectURL(u);no()};im.src=u});
 Object.assign(A,{pickPic(){const i=document.createElement('input');i.type='file';i.accept='image/*';i.style.display='none';i.onchange=async()=>{const f=i.files&&i.files[0];i.remove();if(!f)return;try{S.me.pic=await shrink(f);save();refresh();toast('Photo updated ✓')}catch(e){toast('Could not load that photo')}};document.body.append(i);i.click()},
  rmPic(){delete S.me.pic;save();refresh();toast('Photo removed')}})})();
